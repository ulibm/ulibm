<?
;
     include("../inc/config.inc.php");
	 html_start();


$tbname="svlist";


$c[2][text]="classid";
$c[2][field]="classid";
$c[2][fieldtype]="text";
$c[2][descr]="";
$c[2][defval]="";

$c[3][text]="Name::l::Name";
$c[3][field]="name";
$c[3][fieldtype]="text";
$c[3][descr]="";
$c[3][defval]="";

$c[30][text]="Search Type";
$c[30][field]="stype";
$c[30][fieldtype]="list:title,keyword,isn,titleauth";
$c[30][descr]="";
$c[30][defval]="";

$c[4][text]="url_searchlist";
$c[4][field]="url_searchlist";
$c[4][fieldtype]="text";
$c[4][descr]="";
$c[4][defval]="";

$c[5][text]="searchlist_start";
$c[5][field]="searchlist_start";
$c[5][fieldtype]="longtext";
$c[5][descr]="";
$c[5][defval]="";

$c[6][text]="searchlist_end";
$c[6][field]="searchlist_end";
$c[6][fieldtype]="longtext";
$c[6][descr]="";
$c[6][defval]="";

$c[7][text]="searchlist_sepper";
$c[7][field]="searchlist_sepper";
$c[7][fieldtype]="longtext";
$c[7][descr]="";
$c[7][defval]="";

$c[8][text]="searchlist_bibids";
$c[8][field]="searchlist_bibids";
$c[8][fieldtype]="longtext";
$c[8][descr]="";
$c[8][defval]="";

$c[9][text]="searchlist_bibide";
$c[9][field]="searchlist_bibide";
$c[9][fieldtype]="longtext";
$c[9][descr]="";
$c[9][defval]="";

$c[10][text]="notfoundstr";
$c[10][field]="notfoundstr";
$c[10][fieldtype]="longtext";
$c[10][descr]="";
$c[10][defval]="";

$c[11][text]="foundonestr";
$c[11][field]="foundonestr";
$c[11][fieldtype]="longtext";
$c[11][descr]="";
$c[11][defval]="";

$c[12][text]="extractbibids";
$c[12][field]="extractbibids";
$c[12][fieldtype]="longtext";
$c[12][descr]="";
$c[12][defval]="";

$c[14][text]="extractbibide";
$c[14][field]="extractbibide";
$c[14][fieldtype]="longtext";
$c[14][descr]="";
$c[14][defval]="";

$c[15][text]="url_bib";
$c[15][field]="url_bib";
$c[15][fieldtype]="longtext";
$c[15][descr]="";
$c[15][defval]="";

$c[16][text]="url_bibs";
$c[16][field]="url_bibs";
$c[16][fieldtype]="longtext";
$c[16][descr]="";
$c[16][defval]="";

$c[17][text]="url_bibe";
$c[17][field]="url_bibe";
$c[17][fieldtype]="longtext";
$c[17][descr]="";
$c[17][defval]="";

//dsp



$dsp[3][text]="Name::l::Name";
$dsp[3][field]="name";
$dsp[3][width]="40%";

$dsp[4][text]="classid";
$dsp[4][field]="classid";
$dsp[4][width]="40%";



fixform_tablelister($tbname," 1 ",$dsp,"yes","yes","yes","mi=$mi",$c,"",$o);
	
 ?> 

  <?
  foot();
  ?>