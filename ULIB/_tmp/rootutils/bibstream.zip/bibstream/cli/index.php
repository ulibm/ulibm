<?
include("../inc/config.inc.php");
html_start();
	if ($baseu!="") {
		sessionval_set("baseu",urldecode($baseu));
	}
	if (sessionval_get("baseu")=="") {
		html_dialog("error","base url not found, please refresh");
		die;
	}
	if ($refcode=="") {
		html_dialog("error","no refcode");
		die;
	}
	$delete=trim(addslashes($delete));
	//printr($_GET);
	if ($delete!="") {
		tmq("delete from data where refcode='$refcode' and importid='$delete' ");
	}
?>
  <table width="100%" align=center border="0" cellspacing="0" cellpadding="0">
    <tr valign="top"> 
      <td>
        <form name="form1" action="index.php" method="post" >
          <table width="100%" border="0" cellspacing="1" cellpadding="3">
    <tr align="center">
              <td colspan="3"> 
                <div align="left"><font size="2" face="MS Sans Serif, Microsoft Sans 
Serif">
<?
	// �Ҩӹǹ˹�ҷ�����
  $sql1 ="SELECT distinct importid, count(id) as cc FROM data where refcode='$refcode' group by importid order by importid desc"; 
	$sql2 = "$sql1";
//echo $sql2;
	$result = tmqp($sql2,"index.php?");
	$NRow = tmq_num_rows($result);
							
?> </div>
<BR>

<A HREF="importform.php?refcode=<? echo $refcode;?>" class=a_btn><? echo getlang("����������˹ѧ���������::l::Add data for query"); ?></A>
<A HREF="../run/index.php?refcode=<? echo $refcode;?>&instantsearch=yes" class=a_btn><? echo getlang("���ҷѹ��::l::Instant Search"); ?></A>


                <table width="100%" align=center border="0" cellspacing="1" cellpadding="3" class=table_border>
                  <tr bgcolor="#006699"> 
                    <td width="2%" class=table_head><nobr><? echo getlang("�ӴѺ���::l::No."); ?></nobr></td>
                    <td class=table_head><? echo getlang("�����Ţ��ù����::l::Import ID"); ?></td>
 <td width=200  class=table_head><? echo getlang("�ӹǹ��¡��::l::Count records"); ?></td> 
                    <td width="13%" class=table_head><? echo getlang("ź::l::Delete"); ?></td>
                  </tr>
                  <?
         $i=1; 
				 $count=0;
         while($row = tmq_fetch_array($result)){
			$ID = $row[id];
			$name=$row[name];
			$ittt = (($startrow))+$i;
			echo"<tr bgcolor=#e7e7e7 height=2 valign=top>";

			$importid=$row[importid];
			if ($importid=="") {
				$importid="[EMPTY]";
			}
            echo"<td  class=table_td><font face='MS Sans Serif' size=2>$ittt</font></td>";
            echo"<td  class=table_td><font face='MS Sans Serif' size=2 color=#003366> <a href='sub.php?importid=$importid&refcode=$refcode'>$importid</a>  </font></a></td>";
            $i2 = $i2 +1;  
$count+=$row[cc];
$donec=tmq("select id from data where isdone='yes' and importid='$row[importid]' ");
$donec=number_format(mysql_num_rows($donec));
 echo"<td  class=table_td  align=right>".getlang("��û����ż�::l::Processed")." : $donec/".number_format($row[cc])." - ". number_format(percent_cal ($row[cc],$donec))."%</td><td  class=table_td align=center>";
		//if ($row[importid]!='none') {
			echo " <nobr><A HREF='index.php?refcode=$refcode&delete=$row[importid]' onclick='return confirm(\" $cfrm\") && confirm(\" $cfrm\")' style='color:red'>".getlang("ź�����Ūش���::l::Delete this ImportID")."</A>";
		//} else {
		//	echo "&nbsp;";
		//}
		echo "</td>";
		echo"</tr>";
    $i++;
		$s = $i-1;	
       } 
			echo $_pagesplit_btn_var;
 ?>
</table>
              </td>
            </tr>
          </table>

        </form>
      </td>
    </tr>
  </table>