<?
;
     include("../inc/config.inc.php");
	 html_start();
	if (sessionval_get("baseu")=="") {
		html_dialog("error","base url not found, please refresh");
		die;
	}
	if ($refcode=="") {
		html_dialog("error","no refcode");
		die;
	}

	if ($importid=="") {
		html_dialog("error","no importid");
		die;
	}

$tbname="data";


$c[2][text]="classid";
$c[2][field]="classid";
$c[2][fieldtype]="text";
$c[2][descr]="";
$c[2][defval]="";

//dsp



$dsp[3][text]="��ͤ�������::l::Search";
$dsp[3][field]="data";
$dsp[3][width]="40%";
$dsp[3][filter]="module:localname";
function localname($wh) {
	global $refcode;
	return "<div style=\" width:24px; height:24px; display:block; float:left;\"><a href='../run/index.php?forceid=$wh[id]&refcode=$refcode' target=_blank><img src='../neoimg/foldersearch24.png' width=24 height=24 border=0 ></a></div>".stripslashes($wh[data]);;
}

$dsp[4][text]="�š�ä���::l::Result";
$dsp[4][field]="classid";
$dsp[4][filter]="module:localres";
$dsp[4][width]="40%";

$hideall_js="";

function localres($wh) {
	global $hideall_js;
	global $dcrURL;
	global $limitid;
	$res="";
	if ($wh[isdone]!="yes") {
		return getlang("�ͻ����ż�::l::Wait to process");
	}
	$s2=tmq("select * from svlist where stype='$wh[stype]' ");
	$foundsome="no";
	$resjsid="divresult".randid();
	if ($limitid=="") {
		$res.="<div id='".$resjsid."' style='display:none;' >";
	}
	$foundcount=0;
	while ($r2=tmq_fetch_array($s2)) {
		$resc=tmq("select * from datamatch where sv='$r2[classid]' and pid='$wh[id]' and length(bib)>10 ");
		if (tmq_num_rows($resc)==0) {
			continue;;
		}
		$url_searchlist=$r2[url_searchlist];
		$url_searchlist=str_replace("[[kw]]",urlencode($wh[data])."",$url_searchlist);
		

		$res.= "
		<div style=' width:100%; background-color: transparent; background-image:url($dcrURL/alpha50.png); display:inline-block; border: 0px solid black; border-bottom-width: 1px;' class=alpha70> 
		&nbsp; ".$r2[name]." &nbsp;&nbsp;&nbsp; <a href='$url_searchlist' target=_blank class=smaller2 style='color:#092B5E;'>".getlang("����::l::Search")."</a></div>";
		$res.="<br>"; 

		while ($rescr=tmq_fetch_array($resc)) {
			$urid="bibdata".randid();
			//printr($rescr);
			$rescr[bib]=explodenewline($rescr[bib]);
			$rescr[bib]=arr_filter_remnull($rescr[bib]);
			$rescr[bib]=implode ("
",$rescr[bib]);

			if ($rescr[result]=="found" || $rescr[result]=="foundone" || $rescr[result]=="multifound") {
				$tmptitle=marc_getinfofrom_uglymarc($rescr[bib]);
				if ($rescr[result]=="foundone") {
					$tmptitle="<font color=#FF3300>!</font>$tmptitle";
				}
				//echo $tmptitle;
				$res.="<form method=post action='".sessionval_get("baseu")."library.book/addDBbook.php' target=_blank
				style='margin:0px 0px 0px 0px ;border: silver solid 0px; border-bottom-width:1px; '>
				<input type=hidden name=usethemarc value=yes>
				<input type=hidden name='THEMARC' value=\"".strip_tags($rescr[bib])."\" ID=$urid>
				<div style=\"display:inline-block; width: 320px; height:20px; overflow:hidden; \" class=smaller2><nobr>&nbsp;&nbsp;$tmptitle </nobr></div>
				<input type=submit value=' Get Marc ' style=\"background-color: transparent; border-width: 0px; height: 20px;\"  class=smaller2>
				<a href='javascript:void(null)' onclick=\"alert(getobj('$urid').value);\" class=smaller2>View</a>
				</form>"; 
				$foundsome="yes";
				$foundcount++;
			} 
			if ($rescr[result]=="notfound") {
				$res.="<font class=smaller2 style='color:darkgray'>&nbsp;&nbsp;".getlang("��辺㹰ҹ�����Ź��::l::Not found in this server")."</font><br>";
			}
		}
	}
	$res.="</div>";
	$hideall_js=$hideall_js."tmp=getobj('$resjsid');tmp.style.display='none';
	";
	if ($foundsome=="no") {
		$res.="<font  style='color:#660000'>&nbsp;&nbsp;".getlang("��辺㹰ҹ��������::l::Not found in any server")."</font><br>";
	} else {
		if ($limitid=="") {
			$res.="<div ID='btn$resjsid'><a href=\"javascript:void(null);\"
			onclick=\"hidealljs(); tmp=getobj('$resjsid'); tmp.style.display='block'; tmp=getobj('btn$resjsid'); tmp.style.display='none';\"
			>�������Ũӹǹ $foundcount ��¡��</a></div>"
		;
		}
		$hideall_js=$hideall_js."tmp=getobj('btn$resjsid');tmp.style.display='block';
	";

	}

	//printr($wh);
	return $res;
}
$limit=" importid='".addslashes($importid)."' and refcode='$refcode' ";
if ($limitid!="") {
	$limit=" id=$limitid ";
}
fixform_tablelister($tbname," $limit  ",$dsp,"no","no","no","refcode=$refcode&importid=$importid",$c,"",$o);
	?><script type="text/javascript">
<!--
	function hidealljs() {
		//alert(2);
		<? echo $hideall_js;?>
	}
//-->
</script><?
 ?> 
<center><b><a href="index.php?refcode=<? echo $refcode;?>" class=a_btn><?echo getlang("��Ѻ::l::Back");?></a></b></center>
  <?
  //foot();
  ?>