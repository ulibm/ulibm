<?    /*�ѧ���蹵�Ǩ�ͺ Login ��� Password */
    function ChkLoginAdmintech($useradminid, $passwordadmin)
        {
        global $conn;
        $userSQL="Select * From techadmin Where UserAdminID='$useradminid'  ";
        //echo $userSQL; 
        $result=tmq($userSQL);
        if (!$result)
            die("SELECT �բ�ͼԴ��Ҵ" . mysql_error());
        $num=tmq_num_rows($result);
        $rs=tmq_fetch_array($result);
	   if ($rs[Password]!=$passwordadmin) {
		return false;
	   }

        if (empty($num))
            return false;
        else
            return $rs[Level];
        }
	?>