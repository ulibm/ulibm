<?
function frm_genlist($formname,$sql,$kid,$vid,$dbname="",$allowblank="no",$defval="none",$emponk="",$enponv="non") {
	//typeecho "[frm_genlist($formname,$sql,$kid,$vid,$dbname,$allowblank,$defval,$emponk,$enponv)]";
	$s=aliceos_tmqs($sql,false,$dbname);
	echo "<SELECT NAME='$formname'>";
	if ($allowblank=="yes") {
		echo "<OPTION VALUE=\"\" >";		
	}
	while ($r=tmq_fetch_array($s)) {
		$sl="";
		if ($r[$kid]==$defval) {
			$sl=" selected ";
		}
			echo "<OPTION VALUE=\"$r[$kid]\" $sl ";
			if ($r[$emponk]==$enponv) {
				echo " style='background-color: #DDDDDD; font-weight: bold;' ";
			}
			echo ">".getlang($r[$vid])."</option>";		
	}
	echo "</SELECT>";
}
?>