<?
function marc_getmidcalln($bcode) {
	$s=tmq("select * from media_mid where bcode='$bcode' ",false);
	if (tmq_num_rows($s)==0) {
		return "Item not found (Barcode=$bcode)";
	}
	$s=tmq_fetch_array($s);
	//printr($s);
	$s[calln]=trim($s[calln]);
	if ($s[calln]!='') {
		return $s[calln];
	} else {
		$s=marc_getcalln($s[pid]);
		return $s;
	}
}
?>