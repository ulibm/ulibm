<?
    function frm_restype($NAME, $DEF="",$ALLOPTION="YES",$jsid="") {
	if ($jsid=="") {
		$jsid="autoid".randid();
	}
?>        <select name = "<? echo $NAME;?>" ID="<? echo $jsid?>">
            <?
                $sql82="select * from media_type order by code";
                $result=tmq($sql82);
                //echo $sql;
				if ($ALLOPTION=="YES") {
					echo "<option value=''>".getlang("����˹���������ʴ�::l::not define item type")."</option>";
				}
                while ($row=tmq_fetch_array($result)) {
                    $selornot = "";
                    $DbID=$row[code];
                    if ("$DbID" == $DEF) {
                        $selornot="selected";
                    }
                    $DbDesc=getlang($row[name]);
                    echo "<option value='$DbID' $selornot>$DbID - $DbDesc</option>";
                }
            ?>
        </select>
<?
        }
?>