<?

function iconvth($str) {
  //mb_language("Thai");
  //mb_detect_order ("TIS620, UTF-8, ASCII");
	//printr(mb_get_info());
	$currentenc=mb_detect_encoding($str, "auto");
	//iconv_set_encoding('output_encoding','TIS620');
	
	//if (isUTF8($str)) { echo "yes";} else { echo "no";}
	if ($currentenc!="" && isUTF8($str)) {
		 $str2=iconv("$currentenc","TIS620",$str);///SJIS/EUC-JP/
		 //$str2=mb_convert_encoding($str,'TIS-620',$currentenc); 
	} else {
		$str2=$str;
	}
	//echo"$currentenc [$str=>$str2]<br />";
	return $str2;
}
?>