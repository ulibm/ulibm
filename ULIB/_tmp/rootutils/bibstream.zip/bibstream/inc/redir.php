<?
    function redir($xxx,$sec=0)
        {
?>
        <meta http-equiv = "refresh" content = "<?echo $sec?>;URL=<?echo $xxx?>">
<?
        }

?>