<?
function html_displaymedia($ID) {
	global $dcrURL;
	global $r_2;
	global $r_3;
	global $r_4;
	global $r_5;
	global $r_6;
	global $r_7;
	global $r_8;
	global $r_9;
	global $r_10;
	global $r_11;
	global $r_12;
	global $r_13;
	global $r_14;
	global $r_15;
	global $r_16;
	global $r_17;
	global $r_18;
	global $r_19;
	global $r_20;
	global $r_21;
	global $r_22;
	global $r_23;
	global $r_24;
	global $r_25;
	global $r_26;
	global $r_27;
	global $r_28;
	global $r_29;
	global $r_30;
	global $r_31;
	global $r_32;
	global $r_33;
	global $r_34;
	global $r_35;
	global $_TBWIDTH;
	if (substr($_TBWIDTH,-1)=='%') {
		$_TBWIDTH=780;
	}

	$indi=tmq_dump("bkedit","fid","ishasindi");
	$systemhide=tmq_dump("bkedit","fid","systemhide");
	//$autogentxtbyindi=trim(getval("MARC","autogentxtbyindi"));
	$autogentxtbyindi[tag520][first]["blank"]="<B>Summary:</B> ";
	$autogentxtbyindi[tag520][first][0]="<B>Subject:</B> ";
	$autogentxtbyindi[tag520][first][1]="<B>Review:</B> ";
	$autogentxtbyindi[tag520][first][2]="<B>Scope and content:</B> ";
	$autogentxtbyindi[tag520][first][3]="<B>Abstract:</B> ";
	$autogentxtbyindi[tag246][second][2]="<B>Distinctive title:</B> ";
	$autogentxtbyindi[tag246][second][3]="<B>Other title:</B> ";
	$autogentxtbyindi[tag246][second][4]="<B>Cover title:</B> ";
	$autogentxtbyindi[tag246][second][5]="<B>Added title page title:</B> ";
	$autogentxtbyindi[tag246][second][6]="<B>Caption title:</B> ";
	$autogentxtbyindi[tag246][second][7]="<B>Running title:</B> ";
	$autogentxtbyindi[tag246][second][8]="<B>Spine title:</B> ";
	$autogentxtbyindi[tag505][first][0]="<B>Contents:</B> ";
	$autogentxtbyindi[tag505][first][1]="<B>Incomplete Contents:</B> ";
	$autogentxtbyindi[tag505][first][2]="<B>Partial Contents:</B> ";

$r=marc_melt($ID,"yes");

/*
echo "<PRE>";
print_r($r);
echo "</PRE>";
*/
$coverstr="";
$cov=tmq("select * from media_ftitems where mid='$ID' and fttype='cover' order by text ");
if (tmq_num_rows($cov)!=0) {
	$coverstr.="<table width=150 border=1 align=center cellpadding=1 
cellspacing=1 class=table_border>
	<TR>
		<TD class=table_head>". getlang("�Ҿ��::l::Cover")."</TD>
	</TR>
	<TR>
		<TD class=table_td align=center><table >
<tr>";

	$covi=0;
	while ($covr=mysql_fetch_array($cov)) {

		$covi++;
		$coverstr.= "<TR><td>";
		if($covr[uploadtype]=="url") {
			$covurl=$covr[filename];
		} else {
			$covurl="$dcrURL/_fulltext/$covr[fttype]/$covr[mid]/$covr[filename]";
		}
		 $coverstr.= "<A HREF='$dcrURL/dublin.linkout.php?url=".urlencode($covurl)."'><img src='$covurl' border=1 style='border-color:black' width=120 hspace=3 vspace=0
		 noclass='reflect'></A>";
		 $coverstr.= "</td></TR>";
	}
	$coverstr.="</tr></table></TD>
	</TR>
	</TABLE>";
} else {
	$tags=tmq("select * from media where ID='$ID' ");
	$tags=tmq_fetch_array($tags);
	$covinfo=get_coverbyinfo($tags,"style='float: left;' width=120 hspace=3 vspace=0 noclass='reflect' ");
	if ($covinfo[ispass]=="yes") {
		$covi=1;
		$coverstr.="<table width=150 border=1aalign=center cellpadding=1 
	cellspacing=1 class=table_border><TR>	<TD class=table_head>". getlang("�Ҿ��::l::Cover")."</TD>	</TR>
		<TR>	<TD class=table_td align=center><table ><tr>";
			$coverstr.= "<td>";
			$covurl="$dcrURL/_fulltext/$covr[fttype]/$covr[mid]/$covr[filename]";
			$coverstr.=$covinfo[html];
			$coverstr.= "</td>";
		$coverstr.="</tr></table></TD>
		</TR>
		</TABLE>";
	}
}
$covertdcss="";
if ($coverstr=="") {
	$covertdcss=" style='display:none' ";
}
$retstr="<TABLE  width='".($_TBWIDTH-15)."' border=0 align=center cellpadding=0 
cellspacing=2>
<TR valign=top>
	<TD $covertdcss align=right>$coverstr</TD>
	<TD><!-- startcovertable -->";
	$marctablew=$_TBWIDTH-24;//765;
	if ($covi!=0) {
		$marctablew=$_TBWIDTH-180;//610;
	}
$retstr.="<table bgcolor=darkgray width='$marctablew' border=1 align=center cellpadding=1 
cellspacing=1 bordercolor=#f5f5f5  class=table_border>";

                                        $sql82="select * from bkdsp order by ordr";
                                        $result=tmq($sql82);
										echo mysql_error();
                                        while ($rowd=tmq_fetch_array($result))
                                            {
if (trim($rowd[boundwith])=="") {
	$rowd[boundwith]="all";
	$r["all_num"]=1;
}

/*
echo"<TABLE>
	<TR>
		<TD><PRE>";
print_r($r_2);
	echo"</PRE></TD>
	</TR>
	</TABLE>";
			echo "<PRE>"."$rowd[boundwith]_num"."=[".$r["$rowd[boundwith]_num"]."]</PRE>";
			*/

for ($multiloop=1;$multiloop<=$r["$rowd[boundwith]_num"];$multiloop++) { 

			$x = str_replace("$","$",$rowd[val]);
			$r_orig=$r;
			$userkey="";
			if ($multiloop!=1) {
				$userkey="_$multiloop";
			}
			eval("\$fulldata=\$r$userkey;");
			//echo("\$fulldata=\$r$userkey;<BR>");
			//echo("<B>\$r=\$r$userkey</B><BR>$x<BR>");
			$x=str_replace("\$r[","\$fulldata[",$x);
			//printr("-".$fulldata[tag060_indi]."-");
			eval("\$str = \"$x\";");
			//unset($fulldata);
			$r=$r_orig;

			//echo "[$str]";
			$x2=explodenewline($str);
			$x3=Array();
			foreach ($x2 as $key => $value) {
				$rowd[boundwith]=trim($rowd[boundwith]);
				$autogentxtbyindi_val1="";
				$autogentxtbyindi_val2="";
				if (count($autogentxtbyindi[$rowd[boundwith]])>0) {
					$first_indi=substr($fulldata[$rowd[boundwith]."_indi"],0,1);
					$second_indi=substr($fulldata[$rowd[boundwith]."_indi"],1,1);
					if ($first_indi==" ") {$first_indi="blank";}
					if ($second_indi==" ") {$second_indi="blank";}
					$autogentxtbyindi_val1=$autogentxtbyindi[$rowd[boundwith]][first][$first_indi];
					$autogentxtbyindi_val2=$autogentxtbyindi[$rowd[boundwith]][second][$second_indi];
				}

				$newval="$value";
				//echo "[$newval]";

				if (strlen($newval)==2) {
					$newval='';
				}
				//echo "[$newval]";
				$newval=hidemarc($newval,$rowd[hidefid],$rowd[linksubf]);
				//echo "[$newval]";
				//echo "<PRE>[$newval]</PRE>";
				$newval=dspmarc($newval,$rowd[replacewith]);
				//hide string with limit count
				 if ($rowd[hidestr]!="") {
					  $tmp=explode(",",$rowd[hidestr]);
					  foreach ($tmp as $tmp2) {
						  $tmp3=explode("=",$tmp2);
						  if (!isset($tmp3[2])) {
							$tmp3[2]=0;
						  }
						  $count=intval($tmp3[2]);
							//echo "<PRE>str_replace2($tmp3[0],$tmp3[1],$newval,$count);</PRE>";
						  $newval=str_replace2($tmp3[0],$tmp3[1],$newval,$count);
					  }
				 }
				$newval=trim($newval,$rowd[trimthis]);
				if ($rowd[linkrow]!="") {
					$newval="<A HREF=\"$rowd[linkrow]$newval\">".$newval."</A>";
					//echo "[$dcrURL]";
					$newval=str_replace("[dcr]","$dcrURL",$newval);
				}
				//$newval=hidemarc($newval,$rowd[hidefid],$rowd[hidestr],$rowd[trimthis]);
				$x3[]=$newval;
				//$x2[$key]=str_replace($value,$rowd[hidefid],$rowd[hidestr],$rowd[trimthis]);
			}
			//echo "[$str]";

			unset($fulldata);

			//printr($x3);
			$str=implode($x3,"\n");
			$str=str_replace("\n\n","\n",$str);
			$str=trim($str,"\n");
			$str=str_replace("\n","<BR>",$str);
			//$str=hidemarc($str,$rowd[hidefid],$rowd[hidestr]);
			//echo "$x / -" . trim(dspmarc($str)) . "-";
			//echo "[[$str]]";
			$str=dspmarc($str);
			//echo "[[$str]]";
			if (trim(strip_tags(trim($str)))!="") {
			$retstr.="<tr bgcolor=#f3f3f3 valign=top><td width = 20% valign = top  class=table_head style='text-align:left;'>&nbsp;<nobr>";

$retstr.= getlang($rowd[name]);
$retstr.="</nobr></td>
<td width =70%  class=table_td>";
$str=str_replace("[dcr]","$dcrURL",$str);
//printr($systemhide);
//fulltext display
if ($systemhide[$rowd[boundwith]]=="yes") {
	$retstr.="<img border=0 align=absmiddle src='$dcrURL/neoimg/ulibfulltext.png' TITLE='ULIB - Fulltext management'> ";
}

$retstr.= $autogentxtbyindi_val1;
$retstr.= $autogentxtbyindi_val2;
$retstr.= $str;

//end fulltext display
$retstr.=" </td></tr>";
									
															}
                                            } // end multiloop
											}// end fetch array
$retstr.="</table>";


$retstr.="<!-- endcovertable --></TD>
</TR>
</TABLE>";

return $retstr;
}
?>