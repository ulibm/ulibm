<?
function statordr_add($tbl,$id) {
$tbl=addslashes($tbl);
$id=addslashes($id);

 $tbl="statordr_$tbl";
 
 $c=tmq("select id from $tbl where head='$id'  ");
 $now=time();
 $yea=date("Y");
  if (tmq_num_rows($c)==0) {
 		tmq("insert into $tbl set 
			 head='$id' ,
			  cc=1 ,
			  yea=$yea ,
				lastdt='$now' 
		");
 } else {
   $c=tmq_fetch_array($c);
  	tmq("update $tbl set 
  			  cc=cc+1 ,
  				 lastdt='$now' ,
  				 yea='$yea' 
					  where id='$c[id]'
  		");
 }
}
?>