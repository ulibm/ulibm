<?
    function html_xpbtn($str) {
		//frm= text,url,color [,_target]
		global $dcrURL;
		$str=explode("::",$str);

?><TABLE align='' border = "0" cellspacing = "0" cellpadding =0 >
<TR>
<?
	while (list($k,$v)=each($str)) {
		$i=explode(',',$v);
		//printr($i);
		if ($i[3]=="") {
			$i[3]="_self";
		}
		?>
	<TD>&nbsp;</TD>
	<TD><img src='<?echo $dcrURL?>neoimg/media/roundedge-<? echo $i[2]?>-left.png'></TD>
	<TD background='<?echo $dcrURL?>neoimg/media/roundedge-<? echo $i[2]?>-right.png' style="background-repeat: no-repeat; background-position: top right; padding-right: 10px;padding-left: 4px;"><nobr>
<a  href="<?  echo $i[1]; ?>" target="<? echo $i[3]?>" style="color:white;font-size:14px;font-weight:bold"><? echo getlang($i[0]); ?></a> </nobr></TD><?
	}
?>
</TR>
</TABLE>
<?
        }
?>