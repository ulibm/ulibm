<?
function html_dialog($title="",$text=" ",$width=402) {
	if ($title=="") {
		$title="��ͤ���";
	}
	?>
	<TABLE width=<? echo $width?> align=center class=table_border>
	<TR>
		<TD class=table_head style="color: #7F7F7F"><? echo getlang($title);?></TD>
	</TR>
	<TR>
		<TD class=table_td><? echo getlang($text);?></TD>
	</TR>
	</TABLE>
	<?
}
?>