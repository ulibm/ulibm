<?
function library_gotpermission($code,$chkfor="") {
	global $useradminid;
	if ($chkfor=="") {
		$chkfor=$useradminid;
	}
	//echo "select * from library_permission where lib='$chkfor' and code='$code'  ";
	$tmp=tmq("select * from library_permission where lib='$chkfor' and code='$code'  ");	
	if (tmq_num_rows($tmp)==0) {
		return false;
	} else {
		return true;
	}
}
?>