<?
function explodewithquote($str,$maxlen=10) {
	//$str=str_replace2('  ',' ',$str);
	$str=rem2space($str);
	$str=str_replace("'",'"',$str);
	//echo $str;
	$result="";
	$replacemode=' ';
	$inquote=false;
	for ($i=0;$i<=strlen($str);$i++) {
		$currentchr=$str[$i];
		if ($currentchr=='"') {
			if ($inquote==true) {
				$inquote=false;
			} else {
				$inquote=true;
			}
			if ($inquote==true) {
				$replacemode='[THISISQUOTE]';
			} else {
				$replacemode=' ';
			}
		} 
		if ($currentchr==' ') {
			$result.=$replacemode;
		} else {
			$result.=$currentchr;
		}
	}
	$result=explode(' ',$result);
	while (list($k,$v)=each($result)) {
		$v=stripslashes($v);
		$result[$k]=str_replace('[THISISQUOTE]',' ',$v);
		$result[$k]=trim($result[$k],'"');
	}
	return $result;
}

?>