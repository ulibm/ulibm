<?
function getlcnum($a) {
	//ereg ("([0-9]{3})", $a, $regs);	
	//echo "--$regs[1]--";
	//printr($regs);
	$inf=trim(dspmarc(substr($a,2)));
	$inf=$inf[0];
	//echo "[$inf/$a]";
	//die;
	return trim($inf);
	
}
?>