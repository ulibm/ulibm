<?
function form_member_login() {
	global $dcr;
	global $backto;
	global $_memid;
	global $dcrURL;
	global $_COOKIE;
	//printr($_COOKIE);
	//global $_POST;
	//printr($_POST);
?><table width = "1000" align=center border = 0 cellspacing = "0" cellpadding = "0" align = "center"  >

<TR valign=top>
	<TD align=right valign=middle style="padding-right: 20"><img src="<? echo $dcrURL?>neoimg/lock.png" width=185></TD>
	<TD width=700 align=left>


<table width = "600" border = "0" cellspacing = "1" cellpadding = "3" bgcolor=e2e2e2 class=table_border>
<form action ="/<?echo $dcr;?>/member/login.php" method = post name = a style = "MARGIN: 0px"><INPUT TYPE="hidden" NAME="backto" value="<?echo $backto;?>">
			<tr valign=top>
				<td align = "right" width = "200">
					<b><font face = "Verdana, Arial, Helvetica, 
sans-serif" size = "2"> <? echo getlang("������Ҫԡ::l::Member barcode"); ?> : </font></b></td>
				<td >
<? if ($_memid!="") {
	$tmpdsp=get_member_name($_memid);
	echo "<B>".getlang("�س�����ʶҹ���͡�Թ��������::l::ALREADY LOGED IN").":</B> $tmpdsp<BR>
	<FONT class=smaller2>".getlang("�ҡ�س����� $tmpdsp ��س���͡�Թ���¢����Ţͧ�س::l::If you are not $tmpdsp Please login with your information")."</FONT><BR>";
}?>	
					<input ID = "FC" type = "text" name = "useradminidx" size = "30" class = "unnamed1asd" autocomplete=OFF
					value="<?echo  $_COOKIE["lastmemberloginid"];?>" tabindex=1
					>
					<label class=smaller2 ><INPUT style="border-width:0" TYPE="checkbox" value='yes' NAME="rememberusername" 
					<? if ($_COOKIE["lastmemberloginid"]!="") {
						echo "  checked " ;
					}?>> <? echo getlang("��::l::remember");?></label>
					<?
if (barcodeval_get("webpage-o-canmemberloginbyemail")=="yes") {
	echo "<FONT class=smaller2><BR>".getlang("�س����ö��������ͧ�س��������Ҫԡ��::l::You can use your email address as loginid")."</FONT>";
}
?>
					</td>
			</tr>
			<tr>
<SCRIPT LANGUAGE = "JavaScript">
<!--
getobj('FC').focus()
//-->
</SCRIPT>
				<td align = "right" >
					<b><font face = "Verdana, Arial, Helvetica, 
sans-serif" size = "2"><? echo getlang("���ʼ�ҹ::l::Password"); ?>  : </font></b></td>
				<td >
				<input type = "password" name = "passwordadminx" size = "30" class = "unnamed1asd" tabindex=2></td>
			</tr>
			<tr align = "left">
				<TD></TD>
				<td>
					<b><input type = submit value = "<? echo getlang("�������к�::l::Login"); ?>" name = "submit" class = "frmbtn" tabindex=3> 
					<input type = reset value = "<? echo getlang("ź������::l::Reset"); ?>"  name = "submit2" class = "frmbtn"> <a href="<?echo $dcrURL?>" class=a_btn><? echo getlang("��Ѻ::l::Back"); ?></a>
					</td>
			</tr>					
<?
if (barcodeval_get("memregist-isactive")=="yes") {	
?>			<tr align = "center">
				<TD colspan=2 class=table_td align=right><BR><TABLE align=right>
				<TR>
					<TD><?
	$gstr.="::<B>".getlang("��Ѥ���Ҫԡ�͹�Ź�::l::Online Registration")."</B>,$dcrURL/memregist.form.php,green,_self";
	$gstr.="::".getlang("��Ҫԡ����::l::Accepted Registrant").",$dcrURL/memregist.granted.php,orange,_self";
	$gstr.="::".getlang("���١����ʸ�����Ѥ�::l::Denied records").",$dcrURL/memregist.denied.php,orange,_self";
	html_guidebtn($gstr);
	
?></TD>
				</TR>
				</TABLE>
					</td>
			</tr>
<?}?>
</form>		</table>

</TD>
</TR>
</TABLE>
<?

}
?>