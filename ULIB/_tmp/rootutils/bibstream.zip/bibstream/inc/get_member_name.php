<?
function get_member_name($wh,$addhtml="") {
	global $_memid;
	if ($addhtml=="") {
		$addhtml=" class=smaller ";
	}
	global $dcrURL;
	$s=tmq("select * from member where UserAdminID='$wh' ");
	$r=tmq_fetch_array($s);
	if (trim("$r[UserAdminName]")=="") {
		return "<I><small>".getlang("��辺������Ҫԡ::l::member not found")." $wh</small></I>";
	}
	if (loginchk_lib('check')==true) {
		return "<A HREF='$dcrURL/library.member/detail.php?id=$wh' target=_blank $addhtml>".$r[UserAdminName]."</A>";
	} elseif ($_memid!="") {
		return "<A HREF='$dcrURL/member/viewmember.php?id=$wh' target=_blank $addhtml>".$r[UserAdminName]."</A>";
	} else {
		return "<A HREF='$dcrURL/member/viewmember.php?id=$wh' target=_blank $addhtml>".$r[UserAdminName]."</A>";
	}
}

?>