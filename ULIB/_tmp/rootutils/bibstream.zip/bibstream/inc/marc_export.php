<?
function marc_export($tmp) {
	$s=tmq("select * from media where id='$tmp' ");
	if (tmq_num_rows($s)==0) {
		die ("marc_export($tmp) record not found");
	}
	$s=tmq_fetch_array($s);
	$tags="select * from bkedit order by fid";
		$result=tmq($tags);
		$_RECORD_LENGTH="";//0-4
		$_LEADER="$s[leader]";//5-16
		$_LEADER_1=substr($_LEADER,5,7); //0-11
		$_LEADER_2=substr($_LEADER,17,23); //17-23
		$_BASE_ADDR="";//12-16
		$_DIRECTORY="";
		$_DATASET="";
		$i=0;
		while ($row=tmq_fetch_array($result))	{
			if ($s[$row[fid]]!="") {
				$i++;
				$odata=$s[$row[fid]];
				$odatas=explodenewline($odata);
				foreach ($odatas as $value) {
					if (trim($value)!="") {
						//echo $row[fid]."=$value<BR>";
						$_DIRECTORY = "$_DIRECTORY".
							substr($row[fid],-3)."".
							str_fixw(strlen($value)+1,4)."".
							str_fixw(strlen($_DATASET),5).
							"";
						//$_DATASET = $_DATASET . "" . substr($value,0,2).chr(31).substr($value,2) . chr(30);
						$_DATASET = $_DATASET . "" . $value . chr(30);
					}
				}
			}
		}
		$_BASE_ADDR=str_fixw(strlen("$_LEADER_1$_LEADER_2$_DIRECTORY")+5+5,5);
		$_DATASET=str_replace("^",chr(31),$_DATASET);
		//$_DATASET=str_replace(" ",chr(32),$_DATASET);
	$_RECORD_LEN=str_fixw(strlen("$_LEADER_1$_BASE_ADDR$_LEADER_2$_DIRECTORY$_DATASET")+5,5);
	
	$_RESULT="$_RECORD_LEN$_LEADER_1$_BASE_ADDR$_LEADER_2$_DIRECTORY"."$_DATASET".chr(29);//.chr(32)."";
	return $_RESULT;
}
?>