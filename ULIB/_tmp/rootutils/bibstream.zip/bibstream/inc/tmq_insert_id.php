<?
function tmq_insert_id() {
	$tmpnewid=tmq("select LAST_INSERT_ID() as xx");
	$tmpnewid=tmq_fetch_array($tmpnewid);
	//printr($tmpnewid);
	return floor($tmpnewid[xx]);
}
?>