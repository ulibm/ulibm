<?
function tmq_fetch_array($s) {
	global $_PREVIOUSLY_EXEC_SQL;

	$tmp=mysql_fetch_array($s);
	return $tmp;
	/*
	if ($tmp!=false) {
		return $tmp;
	} else {
		echo "<B>tmq_fetch_array</B> error <BR>_PREVIOUSLY_EXEC_SQL = <PRE>$_PREVIOUSLY_EXEC_SQL</PRE>";
		die;
	}
	*/
}
?>