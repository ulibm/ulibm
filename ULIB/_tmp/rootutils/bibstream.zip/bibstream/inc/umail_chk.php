<?
function umail_chk($email) {
	$email=trim($email);
	if ($email=="") {
		return false;
	}
  if(preg_match("/^([a-zA-Z0-9])+([\.a-zA-Z0-9_-])*@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-]+)*\.([a-zA-Z]{2,6})$/",$email)) {
  return true;
}
  return false;
}
?>