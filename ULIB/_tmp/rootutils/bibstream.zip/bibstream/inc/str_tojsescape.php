<?
function str_tojsescape($wh) {
	////func("str_tojsescape()");
	$wh=str_replace("
","",$wh);
	return $wh;
}
?>