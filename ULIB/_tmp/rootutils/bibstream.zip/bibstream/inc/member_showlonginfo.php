<?
function member_showlonginfo($id,$isfor_ms="") {
	global $_ROOMWORD;
	global $_TBWIDTH;
	global $thaimonstr;
	global $memberspechtml;
	global $_memid;
	global $dcrURL;
	global $dcr;
			$sql2="select * from member where UserAdminID='$id'";
			//echo ($sql2);
			$result2=tmq($sql2);
				$nnnn=tmq_num_rows($result2);
				$s=tmq_fetch_array($result2);

			if ($nnnn == 0)
				{
				html_dialog("","��辺������Ҫԡ���! ��س��к����� ::l::Barcode id not found!");
				die();
				}
		?>
										<br />
<TABLE cellpadding=0 border=0 cellspacing=0 width="<? echo $_TBWIDTH;?>" align=center class=table_border >
<TR valign=top>
	<TD width=50><IMG SRC='<? echo member_pic_url($id);?>' <? echo $memberspechtml?> onerror="this.src='/<? echo $dcr?>/pic/no.jpg'" BORDER=0 ALT=''></TD>
	<TD>
	<TABLE cellpadding=0 border=0 cellspacing=0 width=100% > 
	<TR>
		<TD class=table_head <? echo $addhtmlsizehead;?>><? echo getlang("Barcode::l::Barcode");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo $s[UserAdminID]?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("����::l::Name");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo get_member_name($s[UserAdminID]);
		if ($s[publishbookinfo]=="yes" || loginchk_lib("check")==true || $_memid==$s[UserAdminID]) {
			if (barcodeval_get("webmenu_memfavbook-o-enable")=="yes") {
				echo " <A HREF='$dcrURL/member/viewmember.php?id=$s[UserAdminID]' notarget=_blank class='a_btn smaller2'>View Favourite book</A>";
			}
		}
										?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("��������Ҫԡ::l::Member Type");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><?
		$rooms=tmq("select * from member_type where type='$s[type]'");
		$rooms=tmq_fetch_array($rooms);
		echo getlang($rooms[descr])?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("$_ROOMWORD");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><?
		$rooms=tmq("select * from room where id='$s[room]'");
		$rooms=tmq_fetch_array($rooms);
		echo getlang($rooms[name]);?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("�������::l::Address");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo $s[address]?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("������Ҫԡ::l::Expire");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? 
		//printr($s);
                if ($s[dat] != "" && $s[dat] != 0) {
                    $todate=GregorianToJD2(date('n'), date('j'), date('Y')+543);
                    $mbdate=GregorianToJD2($s[mon], $s[dat], $s[yea]);
					$edt=mktime(0, 0, 0, $s[mon], $s[dat], $s[yea]-543);
                    if ($mbdate >= $todate) {
                        //echo "��Ҫԡ�ѧ����������";
						echo ymd_datestr($edt,'date');
                    } else {
                        echo "<b style='color:red' class=smaller>Expired:".ymd_datestr($edt,'date')."</b>";
                    }
                } else {
                    echo getlang("����ա�á�˹��ѹ���������Ҫԡ::l::No expire date defined");
                }
		?></TD>
	</TR>
	<? if ($isfor_ms=="") {?>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("��������´���::l::Note")?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo $s[descr]?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("������::l::Email")?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo $s[email]?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("�������Ѿ��::l::Tel.")?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo $s[tel]?></TD>
	</TR>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang("�Ң���ͧ��ش::l::Campus");?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo get_libsite_name($s[libsite])?></TD>
	</TR>
<?
$cust=tmq("select * from member_customfield where isshow='yes' order by fid");
while ($custr=tmq_fetch_array($cust)) {
?>
	<TR>
		<TD class=table_head  <? echo $addhtmlsizehead;?>><? echo getlang($custr[name]);?></TD>
		<TD class=table_td <? echo $addhtmlsize;?>><? echo $s[$custr[fid]]?></TD>
	</TR>
<?
}
		} else {


$holdcount=tmq("SELECT *  FROM checkout where hold ='$id' and allow='yes' and returned='no' ");
$holdcount=" <B>".tmq_num_rows($holdcount)."</B>";
$tabstr=getlang("��¡�����::l::Checkout")." $holdcount ";
////////////////////////
$addstr="";
$rqcount="select * from checkout where request='$id'";
$rqcount=tmq_num_rows(tmq($rqcount));
if ($rqcount!=0) {
	$addstr=" <B style='color:red'>($rqcount)</B>";
	$tabstr.=" :: ".getlang("��¡�èͧ::l::Request")." $addstr";
}
////////////////////////
$addstr="";
$rqcount="select * from request_list where memberid='$id' ";
$rqcount=tmq_num_rows(tmq($rqcount));
if ($rqcount!=0) {
	$addstr=" <B style='color:red'>($rqcount)</B>";
	$tabstr.=" ::  ".getlang("��¡�â����::l::Request List")."$addstr";
}
////////////////////////
$addstr="";
$rqcount=tmq("SELECT * FROM fine where memberId='$id' and isdone='no' ");
$rqcountc=tmq_num_rows(($rqcount));
if ($rqcountc!=0) {
	$finecount=0;
	while ($rqcountr=tmq_fetch_array($rqcount)) {
		$finecount=$finecount+floor($rqcountr[fine]);
	}
	$addstr=" <B style='color:red'>($finecount)</B>";
	$tabstr.=" :: ".getlang("��һ�Ѻ::l::Fine")."$addstr";
}

?><TR>
		<TD class=table_head><? echo getlang("��ػʶҹ���Ҫԡ");?></TD>
		<TD class=table_td><? echo $tabstr?></TD>
	</TR>
<?
		}
?>
</table>

</td></tr>
</table>
										<?
}
?>