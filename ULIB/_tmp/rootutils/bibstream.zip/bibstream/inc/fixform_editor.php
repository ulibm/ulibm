<?
function fixform_editor($wh,$tb,$condition,$html="",$options="") {
	global $PHP_SELF;
	global $startrow;
	if ($options[tablewidth]=="") {
		$options[tablewidth]="780";
	}
	?>
	<TABLE width='<? echo $options[tablewidth]?>' align=center class=table_border>
<FORM METHOD=POST ACTION="<? echo $PHP_SELF?>">
<INPUT TYPE="hidden" NAME="ffe_wh" value="<? echo $wh?>">
<INPUT TYPE="hidden" NAME="ffe_tb" value="<? echo $tb?>">
<INPUT TYPE="hidden" NAME="ffe_condition" value="<? echo $condition?>">
<INPUT TYPE="hidden" NAME="startrow" value="<? echo $startrow?>">
<INPUT TYPE="hidden" NAME="ffe_issave" value="yes">
<?
@reset ($wh); 
while (list ($key, $val) = @each ($wh)) { 
  // echo "$key => $val<br />\n";
	//printr($val); 
  fixform_editor_i($val,$tb);
} 	
	?>
	<TR>
		<TD class=table_td colspan=2 align=center><INPUT TYPE="submit" value="<? echo getlang("�ѹ�֡������::l::Submit");?>"><? echo $html;?></TD>
	</TR>
	</FORM>
	</TABLE>
	<?
}
?>