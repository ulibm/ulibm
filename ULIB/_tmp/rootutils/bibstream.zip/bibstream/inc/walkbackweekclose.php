<?
function walkbackweekclose($dat,$mon,$yea) {
	//������ӡ���Ǻ����������ѹ��ش��Ш��ѻ����
	
	$yea=$yea-543;
	$dat=floor($dat);
	$mon=floor($mon);
	$yea=floor($yea);
	$r=tmq("select * from weeklyclose");
		$weeklyclose = ",,,";
	while ($r2=tmq_fetch_array($r)) {
		$weeklyclose = "$weeklyclose,$r2[dat],";
	}

$walkmode=strtolower(getval("_SETTING","checkoutwalkbackmode"));

	// ����ش����Ǻ����������ѹ��ش��Ш��ѻ����   
	//echo "<br>Start: $dat,$mon,$yea";
	//echo "<br>Closed on:".$weeklyclose;
	$modyear =floatval($yea) ;
	//echo $modyear;
	global $thaidaystr;
	$modi=0;
//�֧�����Ũҡ���ҧ closeservice
		$sql4cf="SELECT * FROM closeservice ";
		$result4cf=tmq($sql4cf);
		$closeserv=Array();
		while ($row4cf=tmq_fetch_array($result4cf)) {
			$cdat = $row4cf[dat];
			$cmon=$row4cf[mon];
			if ($row4cf[yea]!=-1) {
				$cyea=$row4cf[yea]-543;
			} else {
				$cyea=date('Y');
			}
			$closeserv[]="$cdat.$cmon.$cyea"; //���ҧ text array ����Ѻ�ѹ��ش
			if ($row4cf[yea]==-1) {
				$cyea=date('Y')+1; //new year eve!
				$closeserv[]="$cdat.$cmon.$cyea"; //���ҧ text array ����Ѻ�ѹ��ش
				$cyea=date('Y')-1; //new year eve!
				$closeserv[]="$cdat.$cmon.$cyea"; //���ҧ text array ����Ѻ�ѹ��ش
			}
		}
		//echo "<br>Close array:".print_r($closeserv,true);;
while (strpos($weeklyclose,date("w",mktime(0, 0, 0, $mon, $dat-$modi, $modyear))) !== false || in_array(date("j.n.Y",mktime(0, 0, 0, $mon, $dat-$modi, $modyear)),$closeserv)) {
	//$weekdat = mktime(0, 0, 0, $mon, $dat-$modi, $modyear);
	//echo date("d m Y",$weekdat) . " =  " . $thaidaystr[date("w",$weekdat)] .  "*** ";
	if ($walkmode=="back") {
		$modi =$modi+1;
	} else {
		$modi =$modi-1;
	}
	//echo " modi=$modi";
}

	$weekdat = mktime(0, 0, 0, $mon, $dat-$modi,  $modyear);
	$tmp= date("d m Y",$weekdat);

	//adding 543 to be thai date
	$tmp=explode(" ",$tmp);
	 $tmp[0]=floor($tmp[0]);
	 $tmp[1]=floor($tmp[1]);
	 $tmp[2]=floor($tmp[2]);

	//echo "<br>Result: $tmp[0] $tmp[1] " . ($tmp[2]);
	//die;///
	return "$tmp[0] $tmp[1] " . ($tmp[2]+543);
	//. " =  " . $thaidaystr[date("w",$weekdat)] .  "*** ";
	//return $tmp;
}
?>