<?
function foot() {
	global $dcr;
	global $_TBWIDTH;
	global $foot_evelcall;
	global $dcr;
	global $dcrURL;
	global $_ISULIBMASTER;	
	global $html_start_title;	
	if ($foot_evelcall=="yes") {
		return;
	}
	$foot_evelcall="yes";
?><!-- �Ѵ������¡Ѻ���ҧ��͹˹�ҷ����� -->
</span>

<!-- end printarea -->
<?
$htmlc=barcodeval_get("webpage-o-mannualhtmlfooter");
$htmlc=trim($htmlc);
$htmlc=stripslashes($htmlc);
$htmlc=stripslashes($htmlc);
if ($htmlc!="") {
	 echo "<center><br />$htmlc</center>";
}
?>
<BR>
  <TABLE WIDTH="<? echo $_TBWIDTH;?>" BORDER=0 CELLPADDING=0 CELLSPACING=0 align=center background="/<? echo $dcr;?>/images/foot_bar.jpg">
	<TR>
		<TD width=1><?
		$cl=barcodeval_get("activateulib-status");
		?>
			<IMG SRC="/<? echo $dcr;?>/images/foot_01<?
			if ($_ISULIBMASTER=="yes") {
				 echo "-master";
			} elseif ($cl=="registered") {
				 echo "-registered";
			}
			?>.jpg" WIDTH=29 HEIGHT=29 
			<?
		if ($_ISULIBMASTER=="yes") {
			 echo " ALT='ULIBM Master site' ";
		} elseif ($cl=="registered") {
			 echo " ALT='Registered ULIB' style='cursor:hand;' onclick=\"window.open('".getval("SYSCONFIG","ulibmasterurl")."activateulib/sv/cert.php?certid=". barcodeval_get("activateulib-refcode")."','ulibcertwin','width=450,height=300');\" ";
		}
		
		?>
			></TD>
		<TD background="/<? echo $dcr;?>/images/foot_head.jpg" valign=bottom style="background-repeat: no-repeat;"><span style="font-weight:bold; color: #F0F0F0; font-size: 12; font-family: Tahoma;";>&nbsp;<?
$tmp= getlang(getval("global","FOOT"));
$yea=date("Y");
if (date("m")<=2) {
	$yea=$yea-1;
}
$tmp=str_replace("[YEAR]",$yea,$tmp);
echo $tmp;
?></span>
		</TD>
		<TD width=1 ><IMG SRC="/<? echo $dcr;?>/images/foot_ulib.jpg" WIDTH=310 HEIGHT=29 ALT="" border=0></TD>
		<TD width=1 >
			<A HREF="#topofpage"><IMG SRC="/<? echo $dcr;?>/images/foot_03.jpg" WIDTH=43 HEIGHT=29 ALT="" border=0></A></TD>
	</TR>
</TABLE>
<script>
document.title="<?
if ($html_start_title=="") {
	echo "".getlang(getval("global","TITLE BAR"));;
} else {
	echo $html_start_title;
}
?>";
</script>
</BODY>
</HTML>
<!-- html end with foot.php -->
<?
}
?>