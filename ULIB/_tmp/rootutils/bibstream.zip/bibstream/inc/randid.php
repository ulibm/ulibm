<?
function randid() {
	////func("randid()");
	return date("YmdHis")."_".rand(0,5000);
}
?>