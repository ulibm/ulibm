<?
function member_showrequest($useradminid2) {
	global $thaimonstr;
	global $_TBWIDTH;
                                ///////////////////////////////////////////��¡�èͧ
                                //echo "��¡�èͧ";
                                $sql="select * from checkout where request='$useradminid2'";
                                $result=tmq($sql);
                                $Num=tmq_num_rows($result);
?><BR><?
								pagesection("��¡�èͧ::l::Request item.","narrow");

                                $count=1; 
                                echo "<table cellpadding=1 cellspacing=0 width='$_TBWIDTH' align=center border=1 class=table_border><tr bgcolor=f2f2f2>
<td align=center class=table_head>".getlang("�ӴѺ���::l::No.")."</td>
<td align=center class=table_head>".getlang("�Ţ���¡::l::CallNo.")."</td>
<td align=center class=table_head>".getlang("��������ͧ::l::Title")."</td>
<td align=center class=table_head>".getlang("�ѹ��͹����::l::Return date")."</td>
<td align=center class=table_head>".getlang("ʶҹС�èͧ::l::Status")."</td>
<td align=center class=table_head>".getlang("¡��ԡ::l::Cancel")."</td></tr>";
                                while ($row2=tmq_fetch_array($result))
                                    {
                                    $media_id = $row2[mediaId];
                                    $Sdat=$row2[edat];
                                    $Smon=$row2[emon];
                                    $Syea=$row2[eyea];
                                    $Sid=$row2[id];
                                    $statint=$row2[returned];
                                    $itemName=dspmarc($row2[mediaName]);
                                    echo "<tr>";
                                    echo "<td class=table_td>$count</td>";
                                    $rowID=$statint;
                                    echo "<td class=table_td> $media_id </td>";
									$parentid=tmq("select * from media_mid where bcode='$media_id' ");
									$parentid=tmq_fetch_array($parentid);
                                    echo "<td class=table_td> <A HREF='../dublin.php?ID=$parentid[pid]&item=$media_id' target=_blank>$itemName...</A> </td>";

                                    echo "<td class=table_td align=center>$Sdat " . $thaimonstr[$Smon] . " $Syea</td>";
                                    if ($statint == "no")
                                        {
                                        $statint=getlang("�ѧ��������Ѻ::l::Nor Ready");
                                        }
                                    else
                                        {
                                        $statint=getlang("������Ѻ����::l::Ready to pickup");
                                        }
                                    echo "<td class=table_td  align=center>$statint</td>";
                                    echo "<td class=table_td  align=center>";
                                    if ($rowID == 'no')
                                        {
                                        echo "<a href='removeRequestItem.php?ID=$Sid'>".getlang("¡��ԡ��èͧ::l::Cancel")."</a>";
                                        }
                                    else
                                        {
                                        echo "-";
                                        }
                                    echo "</td>";
                                    echo "</tr>";
                                    $count++;
                                    }
                                if ($count == 1)
                                    {
                                    echo "<tr><td align=center colspan=6  class=table_td>".getlang("�������¡�èͧ::l::No request item.")."</td></tr>";
                                    }
                                echo "</table>";
}
?>