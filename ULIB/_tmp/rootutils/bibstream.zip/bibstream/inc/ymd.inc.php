<?
if (getlang("t::l::e")=='t') {
  $thaidaystr[0]="�ҷԵ��";
  $thaidaystr[1]="�ѹ���";
  $thaidaystr[2]="�ѧ���";
  $thaidaystr[3]="�ظ";
  $thaidaystr[4]="����ʺ��";
  $thaidaystr[5]="�ء��";
  $thaidaystr[6]="�����";

  $thaidayshortstr[0]="��";
  $thaidayshortstr[1]="�";
  $thaidayshortstr[2]="�";
  $thaidayshortstr[3]="�";
  $thaidayshortstr[4]="��";
  $thaidayshortstr[5]="�";
  $thaidayshortstr[6]="�";


  $thaimonstr[1]="���Ҥ�";
  $thaimonstr[2]="����Ҿѹ��";
  $thaimonstr[3]="�չҤ�";
  $thaimonstr[4]="����¹";
  $thaimonstr[5]="����Ҥ�";
  $thaimonstr[6]="�Զع�¹";
  $thaimonstr[7]="�á�Ҥ�";
  $thaimonstr[8]="�ԧ�Ҥ�";
  $thaimonstr[9]="�ѹ��¹";
  $thaimonstr[10]="���Ҥ�";
  $thaimonstr[11]="��Ȩԡ�¹";
  $thaimonstr[12]="�ѹ�Ҥ�";
  
  $thaimonstrbrief[1]="�.�.";
  $thaimonstrbrief[2]="�.�.";
  $thaimonstrbrief[3]="��.�.";
  $thaimonstrbrief[4]="��.�.";
  $thaimonstrbrief[5]="�.�.";
  $thaimonstrbrief[6]="��.�.";
  $thaimonstrbrief[7]="�.�.";
  $thaimonstrbrief[8]="�.�.";
  $thaimonstrbrief[9]="�.�.";
  $thaimonstrbrief[10]="�.�.";
  $thaimonstrbrief[11]="�.�.";
  $thaimonstrbrief[12]="�.�.";
  } else {
  $thaidaystr[0]="Sunday";
  $thaidaystr[1]="Monday";
  $thaidaystr[2]="Tuesday";
  $thaidaystr[3]="Wednesday";
  $thaidaystr[4]="Thursday";
  $thaidaystr[5]="Friday";
  $thaidaystr[6]="Saturday";

  $thaimonstr[1]="January";
  $thaimonstr[2]="Febuary";
  $thaimonstr[3]="March";
  $thaimonstr[4]="April";
  $thaimonstr[5]="May";
  $thaimonstr[6]="June";
  $thaimonstr[7]="July";
  $thaimonstr[8]="August";
  $thaimonstr[9]="September";
  $thaimonstr[10]="October";
  $thaimonstr[11]="November";
  $thaimonstr[12]="December";
  
   $thaimonstrbrief[1]="Jan";
  $thaimonstrbrief[2]="Feb";
  $thaimonstrbrief[3]="Mar";
  $thaimonstrbrief[4]="Apr";
  $thaimonstrbrief[5]="May";
  $thaimonstrbrief[6]="Jun";
  $thaimonstrbrief[7]="Jul";
  $thaimonstrbrief[8]="Aug";
  $thaimonstrbrief[9]="Sep";
  $thaimonstrbrief[10]="Oct";
  $thaimonstrbrief[11]="Nov";
  $thaimonstrbrief[12]="Dec";

}

$engseasonstr[21]="Spring";
$engseasonstr[22]="Summer";
$engseasonstr[23]="Autumn";
$engseasonstr[24]="Winter";

?>