<?php
//Generation of font definition file for tutorial 7
require('../font/makefont/makefont.php');


if ($handle = opendir('./step1_source/')) {
    echo "Directory handle: $handle<BR>";
    echo "Files:<BR><HR>";
	echo "ddddddddddddddddddd.";

    /* This is the correct way to loop over the directory. */
    while (false !== ($file = readdir($handle))) {
		echo $file;
		$t=explode('.',$file);
		//print_r($t);
		if (strtoupper($t[count($t)-1])=="TTF") {
			echo "<B>".$t[count($t)-1]."</B>$file<BR>\n";
			MakeFont("./step1_source/$file","./step1_source/$file.afm","cp874");
		}
    }


    closedir($handle);
} else {
	echo "cannot open dir;";
}
?> 