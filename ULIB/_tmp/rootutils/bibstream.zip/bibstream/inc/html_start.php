<?
function html_start($isbody="yes") {
	global $html_start_evelcall;
	global $html_start_title;

	global $dcr;
	global $dcrURL;
	if ($html_start_evelcall=="yes") {
		return;
	}
	$html_start_evelcall="yes";
	if ($html_start_title=="") {
		$html_start_title="�к���ͧ��ش�ѵ��ѵ� ULibM";
	}
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE><? echo $html_start_title; ?></TITLE>
<?
//$html_start_title="";	
?>
<link rel="shortcut icon" type="image/x-icon" href="<? echo $dcrURL?>neoimg/ulibfavicon.png" />
<link rel="icon" type="image/x-icon" href="<? echo $dcrURL?>neoimg/ulibfavicon.png" />
<?
echo stripslashes(barcodeval_get("webpage-o-pagemetadata"));
?>
<script language="javascript" src="<? echo $dcrURL?>js/reflection.js" type="text/javascript">
</script>
<script language="javascript" src="<? echo $dcrURL?>js/dom-drag.js" type="text/javascript">
</script>
<link rel="stylesheet" type="text/css" href="<? echo $dcrURL?>css/css.php" />
<SCRIPT LANGUAGE="JavaScript" src="<? echo $dcrURL?>js/ajaxroutine.js">
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript" src="<? echo $dcrURL?>js/common.js">
</SCRIPT>

<script type="text/javascript"> 
var GB_ROOT_DIR = "<? echo $dcrURL?>js/greybox/";
function removegb() {
	GB_hide();
}
</script>
<script type="text/javascript" src="<? echo $dcrURL?>js/greybox/AJS.js"></script> 
<script type="text/javascript" src="<? echo $dcrURL?>js/greybox/AJS_fx.js"></script> 
<script type="text/javascript" src="<? echo $dcrURL?>js/greybox/gb_scripts.js"></script> 
<link href="<? echo $dcrURL?>js/greybox/gb_styles.css" rel="stylesheet" type="text/css" /> 

</HEAD>
<?
	if ($isbody=="yes") {
		echo "<BODY>";
	}
}
?>