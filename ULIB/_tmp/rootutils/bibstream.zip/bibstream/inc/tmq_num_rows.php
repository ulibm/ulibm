<?
function tmq_num_rows($t) {
	return mysql_num_rows($t);
}
?>