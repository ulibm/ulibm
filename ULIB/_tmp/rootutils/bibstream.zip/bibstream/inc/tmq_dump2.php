<?
function tmq_dump2($tb,$k,$v ,$bl="",$DB = "") {
	////func(" tmq_dump($tb,$k,$v ,$bl)");
	if ($DB=="") {
		$tmqfunc="tmq";
		$OSDB="";
	} else {
		$tmqfunc="aliceos_tmqs";
		$OSDB=$DB;
	}
	//echo"*[$tmqfunc]*";

	$s=$tmqfunc("select * from $tb  $bl",false,$OSDB);
	$pos = strrpos($v, ",");
	if (is_bool($pos) && !$pos) {
		while ($r=tmq_fetch_array($s)) {
			$tmp[$r["$k"]]=$r[$v];
		}
	} else {
		$v=explode(",",$v);
		while ($r=tmq_fetch_array($s)) {
			foreach ($v as $key => $value) {
				$tmp[$r["$k"]][$key]=$r[$value];
			}
		}
	}
	////func(" tmq_dump finished");

	return $tmp;
}
?>