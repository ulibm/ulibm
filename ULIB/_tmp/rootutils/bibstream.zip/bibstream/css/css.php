<?
	; 
		header("Content-Type: text/css");
        include ("../inc/config.inc.php");
       // include ("./c.inc.php");
		$tmp= file_get_contents("./ulib5.css");
		$tmp=str_replace('$dcrURL',$dcrURL,$tmp);
		echo $tmp;
?>