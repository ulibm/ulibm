DBF Explorer by Pablo Software Solutions Version 1.0 Build 004

Introduction
DBF Explorer is an application for viewing and editing DBF files (dBase III). It has a Easy-to-Use, simple and intuitive interface.
You can add, edit, delete/undelete records, modify field structure, create new DBF database files, find/replace and pack records. The code is partially based on Turbo C source code(created in 1987!) by Mark Sadler, but has been totally rewitten to be compatible with 32 bits and lots of functionality has been added.
The application also includes printing/print preview and export to text and html files.
DBF Explorer does not require external drivers for connection to databases (ODBC, BDE). Supports Windows 95/98/ME/NT/2000. 


Installation
Installing DBF Explorer is as simple as unzipping the executable in a folder of you choice, for example C:\Program Files\DBF Explorer.
Create a shortcut on the Start Menu of on your desktop and DBF Explorer will be ready to use.

Menu options

File Menu

New 
New brings up the Edit Database Structure Dialog where you can define the structure of the database. See Modify Structure.
Open
Opens an existing database.
Close 
Close the active database.
Save 
Save the active database. This command is only available when you have created a new file. All other modifications to the database are saved automatically.
Save As
Save the active database with a new name.
Pack Database
Removes all deleted records from the database: When you delete a record it is not really removed from the database, but only 'marked' as deleted. This allows you to recover a delete record with the Undelete Record(s) option. If you choose to pack the database, it will recreate the file without the records that were marked as deleted.
Modify Structure
Modify Structure allows you to change the structure of the database. Keep in mind that after you apply the changes, some data that was already in the database may be lost. This is because some datatypes can't be converted to another format. DBF Explorer will automatically make a backup before convertion the database to a new structure. The first character of the backup filename will be replaced by a '_'.

Edit Menu

Add Record
Appends a new record to the end of the database and puts this record in edit mode.
Edit Record
Puts the currently selected record in edit mode.
Delete Record(s)
Delete the current selected record(s). Records will only be marked as deleted. To really remove them from the database use the Pack Database option.
Undelete Record(s)
Undelete the current selected record(s). The 'mark as deleted' flag will be reset.
Find 
Find specific text. The record in which the text was found will be selected.
Find Next
Repeats the last find.
Replace
Replace specific text with different text.
Select All
Select all records in the active database.

View Menu

Toolbar
Show or hide the toolbar
Statusbar
Show or hide the statusbar
Show Deleted Records
Show or hide deleted records.

� Copyright 2002 Pablo Software Solutions



