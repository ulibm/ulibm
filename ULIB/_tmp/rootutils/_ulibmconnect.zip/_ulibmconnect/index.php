<?php
	// peace out
	//header( "Location: login.php" );
	include("login.php");
	?>