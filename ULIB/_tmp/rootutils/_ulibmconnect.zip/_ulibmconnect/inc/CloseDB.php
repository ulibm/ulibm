<?
    function CloseDB()
        {
        global $conn;
        Mysql_close($conn);
        }
?>