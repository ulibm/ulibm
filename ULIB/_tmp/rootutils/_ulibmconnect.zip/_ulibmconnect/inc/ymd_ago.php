<?
function ymd_ago($timestamp){
	if ($timestamp==0) {
		return "-";
	}
   $difference = time() - $timestamp;
   if ($difference<=60) {$difference=60;}
   $periods = array(getlang("�Թҷ�::l::seconds"), getlang("�ҷ�::l::minutes"), getlang("�������::l::hours"), getlang("�ѹ::l::days"), getlang("�ѻ����::l::weeks"), getlang("��͹::l::months"), getlang("��::l::years"), "decade");
   $lengths = array("60","60","24","7","4.35","12","10");
   for($j = 0; $difference >= $lengths[$j]; $j++)
   $difference /= $lengths[$j];
   $difference = round($difference);
   //if($difference != 1) $periods[$j].= "s";
   $text = "$difference $periods[$j] ".getlang("�������::l::ago");
   return $text;
  }
?>