<?
function loginchk_root() {
	global $_SESSION;
	global $loginadmin;
	global $Level;
	//printr($loginadmin);
	if ($loginadmin != true || $Level != "Root")
        {
        form_root_login();
        echo "<center><font face ='ms sans serif' size =2 color = red>";
        echo getlang("Login ���� Password ���١��ͧ �ô��Ǩ�ͺ�ա����::l::Login or Password is incorrect, please try again.");
        echo "</font></center>";
		die;
        }
}
?>