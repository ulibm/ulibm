<?
function  serial_rebuild_serialstr($MID) {
	$s=tmq("select * from media_mid where pid='$MID' ");
	$res="";
	$decis_type=(getval("MARC","serial-bound-mdtype"));
	$decis=strtolower(getval("MARC","seriallibhas_skipbound"));
	echo "$decis_type-$decis";
	while ($r=tmq_fetch_array($s)) {
		//$res.="". trim(serial_get_volstr($r[id]). " " . $r[javaistatusnote] ). ";";
		//printr($r);
		if ($r[RESOURCE_TYPE]=="$decis_type" && $decis=="yes") {
			continue;
		}
		$res.="". trim(serial_get_volstr($r[id])). ";";
	}
	$res=trim($res,";");
	$tag=getval("MARC","serialtag");
	tmq("update media set ".$tag."='  ^a$res' where ID='$MID' ");
	//echo $res;
}
?>