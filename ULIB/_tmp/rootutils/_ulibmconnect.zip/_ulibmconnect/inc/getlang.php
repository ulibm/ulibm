<?
function getlang($str,$tmplang="") {
	global $_SESSION;
	$str=explode("::l::",$str);
		if (!isset($_SESSION['lang_control_val']) || $_SESSION['lang_control_val']=='th' || trim($str[1])=="" || $tmplang=="th") {
			$tmpl1= $str[0];
		} elseif ($_SESSION['lang_control_val']=='en' || $tmplang=="en") {
			$tmpl1= $str[1];
		}

	return $tmpl1;
}
?>