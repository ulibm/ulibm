<?
function member_pic_url($useradminid) {
	global $dcr;
	$place=barcodeval_get("memberpic-wheresave");
	if ($place=="local") {
		$suff=barcodeval_get("memberpic-local-suffix");
		$pref=barcodeval_get("memberpic-local-prefix");
		return "/$dcr/pic/$pref$useradminid$suff";
	} else {
		$suff=barcodeval_get("memberpic-global-suffix");
		$pref=barcodeval_get("memberpic-global-prefix");
		return "$pref$useradminid$suff";
	}
}
?>