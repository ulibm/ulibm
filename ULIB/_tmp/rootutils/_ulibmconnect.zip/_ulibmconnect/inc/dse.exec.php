<?
dse_strapval();
dse_doval();
?>