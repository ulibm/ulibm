<?
function bitem_get_checkoutstr($mMID) {
global $thaimonstr;
  $sql25 ="SELECT *  FROM checkout where mediaId='$mMID' ";
//echo $sql25;
$result25 = tmq($sql25);
   $Num = tmq_num_rows($result25);  
     $row25 = tmq_fetch_array($result25);
                 $itemid = $row25[id];
                 $itemhd = $row25[hold];
                 $itemrq = $row25[request];
                 $itemedat = $row25[edat];
                 $itememon = $row25[emon];
                 $itemeyea = $row25[eyea];

//   echo "$Num";
if ($Num==0) {

     $ecstat="<FONT  COLOR=0000ff>".getlang("�����::l::On shelf")."</FONT>";

} else { //�ҡ������㹵��ҧ checkout
    if ($itemrq!="") {
      $ecstat.=getlang("�١��� ��˹����ѹ��� ::l::On due return at ") . " <nobr>" . $itemedat . " " . $thaimonstr[$itememon] . " " . $itemeyea ."</nobr> " . getlang("����ա�èͧ���::l:: with request"); 
	} else {
	  $ecstat .= getlang("�١��� ��˹����ѹ��� ::l::On due return at ") . "  <nobr>" . $itemedat . " " . $thaimonstr[$itememon] . " " . $itemeyea ."</nobr> <br />
<A HREF='requesthold_form.php?ID=$mMID'>&nbsp;<img align=absmiddle border=0 src='$dcrURL"."neoimg/Right16.gif'> ".getlang("�ͧ::l::Request")."</A> ";	
	}
} 
return $ecstat;
}
?>