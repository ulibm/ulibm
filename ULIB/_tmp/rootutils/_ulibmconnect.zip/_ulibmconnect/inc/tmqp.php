<?
function tmqp($sql,$url,$notfoundstr="��辺������::l::No result found",$row_per_pagex="") {
	////func(" tmqp($sql,$startrow,$url,$is_os)");
	/*
	limitpage_var ();
	tmqp("select * from npc ",$startrow,"index.php?npc=$npc");
	*/

	global $startrow;
	//$startrow=$page;
	if ($startrow=="" || $startrow==0) {
		$startrow=0;
	}
	global $dcrURL;
	global $_pagesplit_btn_var;
	if ($row_per_pagex=="") {
  	$row_per_page=getval("pagesplit","pagelength");
	} else {
		$row_per_page=$row_per_pagex;
	}
	$page_per_page=getval("pagesplit","pagenumlength");
	$tmpsql_count=stripos($sql,' group by '); //test for group by
	$tmpsql_countas=stripos($sql,' as '); //test for as select
	//echo "[$tmpsql_count]";
	//echo "[$sql=$tmpsql_countas]";
	if ($tmpsql_count>3 || $tmpsql_countas>3) {
		//must do nothing
		$result=tmq($sql,false);
		$total_row = tmq_num_rows($result); //���Ҩӹǹ��÷Ѵ���������е�ͧ�ʴ� 
	} else {
		$sql_count=substr($sql,stripos($sql,'from'),strlen($sql));
		//echo $sql_count;
		$tmpsql_count=strripos($sql_count,' order by ');
		if ($tmpsql_count<5) {
			$tmpsql_count=strlen($sql_count);
		}
		$sql_count=substr($sql_count,0,$tmpsql_count);
		$sql_count="select count(*) as tmpqcount $sql_count";
		//echo $sql_count;
		$result = tmq($sql_count,false); 
		$result=tmq_fetch_array($result);
		//printr($result);
		$total_row = floor($result[tmpqcount]); //���Ҩӹǹ��÷Ѵ���������е�ͧ�ʴ� 
	}
	//

		$total_page = intval((($total_row-1)/$row_per_page)+1); //�Ҥ�Ҩӹǹ˹�ҷ���������ͧ�ʴ� 
		$currentpage = (($startrow)/$row_per_page)+1; //�����˹�ҷ���ʴ�����Ѩ�غѹ��˹�ҷ��������� 



	$total_page = intval((($total_row-1)/$row_per_page)+1); //�Ҥ�Ҩӹǹ˹�ҷ���������ͧ�ʴ� 
	//$currentpage = (($startrow)/$row_per_page)+1; //�����˹�ҷ���ʴ�����Ѩ�غѹ��˹�ҷ��������� 
	$result = tmq($sql." LIMIT $startrow,$row_per_page",false); 
	/* Get your result to return to func-caller*/
	
	/*displaying*/
	$displaying=tmq_num_rows($result);

	/* getting str to show on prev page*/
$page_amnt_per_page_range=getval("pagesplit","pagenumlength");
	if ($total_page>1) { //��Ǩ����Ҷ�Ҩӹǹ˹�ҷ��������Թ 1 ˹�� ��ͧ�ʴ���÷Ѵ����������͡˹�� 
		$page_show = ""; 
		//echo "[[ total_page=$total_page, row_per_page=$row_per_page , currentpage=$currentpage , page_per_page=$page_per_page ]]";
		$for_from=$currentpage-$page_per_page;
		$for_to=$currentpage+$page_per_page;
		//echo "for [$for_from,$for_to]";
		if ($for_from<1) {
			$for_from=1;
		}
		if ($for_to>$total_page) {
			$for_to=$total_page;
		}

		for ($i=$for_from;$i<=$for_to;$i++) {
			//echo "[for - $i]";
			if ($i==$currentpage) {
				$page_show = " $page_show  <B>$i</B>  "; 
			} else {
				$nextstartrow=($i*$row_per_page)-$row_per_page;
				$page_show = " $page_show  <A HREF='$url&startrow=".($nextstartrow)."'><U>$i</U></A> "; 
			}
		}

		//�������õ�Ǩ�ͺ����ԧ�� |<   <<    >>   >|
		if (($currentpage-1)>0 ) {
			$nextrow=($currentpage-2)*$row_per_page;
			$page_show = "<A HREF='$url&startrow=".($nextrow)."'><img src='$dcrURL/images/page/back.gif' width=15 height=15 align=absmiddle border=0 title='˹�ҡ�͹˹��'></A> $page_show"; 
		} else {
			$page_show = "<img src='$dcrURL/images/page/back_dis.gif' width=15 height=15 align=absmiddle border=0 title='˹�ҡ�͹˹��'> $page_show"; 
		}
		if ($currentpage!=1) {
			$nextrow=0;
			$page_show = "<A HREF='$url&startrow=".($nextrow)."'><img src='$dcrURL/images/page/first.gif' width=15 height=15 align=absmiddle border=0 title='˹���á'></A> $page_show"; 
		} else {
			$page_show = " <img src='$dcrURL/images/page/first_dis.gif' width=15 height=15 align=absmiddle border=0 title='˹���á'> $page_show"; 
		}

		if ($currentpage<$total_page) {
			$nextrow=($currentpage)*$row_per_page;
			$page_show = " $page_show <A HREF='$url&startrow=".($nextrow)."'><img src='$dcrURL/images/page/next.gif' width=15 height=15 align=absmiddle border=0 title='˹�ҵ���'></A> "; 
		} else {
			$page_show = " $page_show <img src='$dcrURL/images/page/next_dis.gif' width=15 height=15 align=absmiddle border=0 title='˹�ҵ���'> "; 
		}
		if ($currentpage!=$total_page) {
			$nextrow=($total_page-1)*$row_per_page;
			$page_show = " $page_show <A HREF='$url&startrow=".($nextrow)."'><img src='$dcrURL/images/page/last.gif' width=15 height=15 align=absmiddle border=0 title='˹�ҷ����ش'></A> "; 
		} else {
			$page_show = " $page_show <img src='$dcrURL/images/page/last_dis.gif' width=15 height=15 align=absmiddle border=0 title='˹�ҷ����ش'> "; 
		}
			$page_show = " $page_show [$total_page] "; 

	} else { 
		$page_show = ""; 
	} 

	$_pagesplit_btn_var="&nbsp;" . $page_show ."&nbsp;";
	$_pagesplit_btn_var=" <tr><td colspan=10 align=center bgcolor=fcfcfc>" . $_pagesplit_btn_var ." <span style=\"font-size: 10; color: 888888;\">[".getlang("�ʴ�::l::Displaying")." $displaying/$total_row ".getlang("��¡��::l::<B></B>")."]</span></td></tr> ";
	if ($total_row==0) {
				$_pagesplit_btn_var="<TR>
			<TD bgcolor=f5f5f5 colspan=10 align=center style=\"padding-top: 7px; padding-bottom: 7; color: #A6A6A6\"><B>".getlang("$notfoundstr")."</B></TD>
		</TR>";
		if ($notfoundstr=="skip" || $notfoundstr=="no") {
			$_pagesplit_btn_var="";
		}
	}

	return $result;
}
?>