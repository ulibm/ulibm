<?
function pagesection($txt,$mode="normal",$col="#666666") {
	global $dcrURL;
	//echo "[$mode]";
	global $_TBWIDTH;
	if ($mode=="") {
		$mode="normal";
	}
	if ($mode=="normal") {
?><TABLE width=700 height=65 align=center cellspacing=10 background="<? echo $dcrURL?>/neoimg/pagesection.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD align=left style="padding-left: 120px" valign=middle><FONT SIZE="" COLOR=""  style="font-size: 22px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}
	if ($mode=="login") {
?><TABLE width=700 height=65 align=center cellspacing=10 background="<? echo $dcrURL?>/neoimg/pagesection-login.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD nostyle="padding-right: 60px" valign=middle align=center><FONT SIZE="" COLOR=""  style="font-size: 30px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}

	if ($mode=="stats") {
?><TABLE width=700 height=65 align=center cellspacing=10 background="<? echo $dcrURL?>/neoimg/pagesection-stats.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD nostyle="padding-right: 60px" valign=middle align=center><FONT SIZE="" COLOR=""  style="font-size: 30px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}

	if ($mode=="fulltext") {
?><TABLE width=700 height=65 align=center cellspacing=10 background="<? echo $dcrURL?>/neoimg/pagesection-fulltext.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD nostyle="padding-right: 60px" valign=middle align=center><FONT SIZE="" COLOR=""  style="font-size: 30px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}
	if ($mode=="article") {
?><TABLE width=100% height=65 align=center cellspacing=10 background="<? echo $dcrURL?>/neoimg/pagesection-fulltext.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD style="padding-right: 20px" valign=middle align=right><FONT SIZE="" COLOR=""  style="font-size: 30px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}
	if ($mode=="bookcomment") {
?><TABLE width="<? echo $_TBWIDTH?>" height=65 align=center cellspacing=10 background="<? echo $dcrURL?>/neoimg/pagesection-fulltext.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD style="padding-left: 150px" valign=middle align=left><FONT SIZE="" COLOR=""  style="font-size: 30px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}
	if ($mode=="articlelist") {
?><TABLE border=0 width=100% height=35 align=center cellspacing=3 background="<? echo $dcrURL?>/neoimg/pagesection-fulltext.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD style="padding-left: 120px" valign=middle align=left><FONT SIZE="" COLOR=""  style="font-size: 20px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}
	if ($mode=="narrow") {
		$col="white";
?><TABLE width=780 height=20 align=center cellspacing=2 background="<? echo $dcrURL?>/neoimg/pagesection-narrow.jpg" bgcolor=#334277 style="background-repeat: no-repeat;">
<TR>
	<TD  valign=middle align=center><FONT SIZE="" COLOR=""  style="font-size: 16px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}
	
	if ($mode=="usissearchsection") {
		$col="black";
?><TABLE width=780 height=32 align=center cellspacing=2 background="<? echo $dcrURL?>/neoimg/pagesection-usis.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD  valign=middle align=left style="padding-left: 100"><FONT SIZE="" COLOR=""  style="font-size: 20px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}	
	if ($mode=="requestroom") {
		$col="#246C26";
?><TABLE width=780 height=43 align=center cellspacing=3 background="<? echo $dcrURL?>/neoimg/pagesection-requestroom.jpg" style="background-repeat: no-repeat;">
<TR>
	<TD style="padding-left: 90px" valign=middle align=left><FONT SIZE="" COLOR=""  style="font-size: 22px; font-weight: bolder; color: <? echo $col;?>"><?echo getlang($txt);?></FONT></TD>
</TR>
</TABLE><?
	}



}
?>