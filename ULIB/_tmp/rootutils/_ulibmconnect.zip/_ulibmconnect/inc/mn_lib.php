<?
function mn_lib() {
	global $loginadmin;
	global $useradminid;
	global $dcr;
	global $dcrURL;
	global $PHP_SELF;
	global $dcrs;
	global $LIBSITE;
	global $_REQPERM;
	global $_FACULTYWORD;
	global $_ROOMWORD;
	global $_TBWIDTH;
	loginchk_lib();

	if ($_REQPERM=="") {
		die("<B>mn_lib()</B> error: require \$_REQPERM;");
	}
	$rq=tmq("select * from library_modules where code='$_REQPERM' ");
	if (tmq_num_rows($rq)==0) {
		die("library_modules where code='$_REQPERM'");
	}
	$rq=tmq_fetch_array($rq);

	$rqc=tmq("select * from library_modules_cate where code='$rq[nested]' ");
	if (tmq_num_rows($rqc)==0) {
		die("library_modules_cate where code='$rq[nested]'");
	}
	$rqc=tmq_fetch_array($rqc);
	
	if (!library_gotpermission($_REQPERM)) {
		html_dialog("Security alert","�س������Է��������ҹ��ǹ���");
		die;
	}
	?>
  <table width="<? echo $_TBWIDTH?>" border="0" cellspacing="0" cellpadding="0" align=center>
    <tr>
      <td>
	  
	  
    <table width="100%" border="0" cellspacing="1" cellpadding="3" 
bgcolor="#E2E2E2" background="">
          <tr>
            <td ><b><font face="MS Sans Serif" size="5" 
color="000000" >&nbsp;<font color="#FF9900" class=stupidmenu>
<? echo getlang("�к����˹�ҷ����ͧ��ش::l::Librarian System"); ?>
              </font></font> <? echo get_libsite_name($LIBSITE);?></b> <?
	if (library_gotpermission("switchownlibsite")) {
		echo "<FONT class=smaller2>[<A HREF='$dcrURL"."library/mainadmin.php?switchlibsite=yes' class=smaller2>".getlang("���͡::l::Set")."</A>]</FONT>";
	}
	?></td>
	<TD align=right><nobr><span style="color: 999999;">
<img src='<? echo $dcrURL?>neoimg/userlock.png' align=absmiddle>
<? echo get_library_name($useradminid,true);?>
</span>&nbsp;&nbsp;</nobr></TD>
          </tr>
        </table>
		
		
      </td>


    </tr>
<TR bgcolor=f1f1f1><td>


<TABLE width="<? echo $_TBWIDTH?>" border=0 bgcolor=f1f1f1 cellpadding=2 cellspacing=0>
<TR align=center>
<td align=left style="padding-left: 20px;"><nobr><font style='font-size: 12px;color:#39537D'>
<?
$url="";
if ( $rqc[isplayathead]!="no") {
	if ( $rqc[url]!="") {
		$rqc[url]=str_replace('[dcr]',$dcrURL,$rqc[url]);
		$url="<A HREF='$rqc[url]' style='font-size: 12px;color:#39537D'>";
	}
	$url=str_replace('//','/',$url);
	$url=str_replace('http:/','http://',$url);
	echo "<img src='$dcrURL/neoimg/menuicon/folder.png' align=absmiddle>&nbsp;$url".getlang($rqc[name])."</A> ";
}
$url="";
if ( $rq[url]!="") {
	$rq[url]=str_replace('[dcr]',$dcrURL,$rq[url]);
	$url="<A HREF='$rq[url]'  style='font-size: 12px;'>";
}
$url=str_replace('//','/',$url);
$url=str_replace('http:/','http://',$url);
	$rq[name]=str_replace('[ROOMWORD]',$_ROOMWORD,$rq[name]);
	$rq[name]=str_replace('[FACULTYWORD]',$_FACULTYWORD,$rq[name]);
	$rq[name]=getlang($rq[name]);
	$len=30;
	if (strlen($rq[name])>$len) {
		$rq[name]=substr($rq[name],0,$len).'..';
	}
echo "<img src='$dcrURL/neoimg/menuicon/$rq[icon].png' align=absmiddle>&nbsp;$url".stripslashes($rq[name])."</A> ";

?></font></nobr>
</td>
<td width=450  background="/<?  echo "$dcr"; ?>/neoimg/menufade_1.png" style="background-repeat: no-repeat;background-position: top left; text-align:right; padding-right: 10px;" align=right>


<TABLE align=right border = "0" cellspacing = "0" cellpadding =0 >
<TR >

<?
  $PHP_SELF=str_replace('//','/',$PHP_SELF);
	//echo "$PHP_SELF";
	$homebtn=tmq("select * from library where UserAdminID='$useradminid'");
	$homebtn=tmq_fetch_array($homebtn);
	if ($homebtn[defmenu]!="") {
		$homebtn=tmq("select * from library_modules where code='$homebtn[defmenu]' ");
		$homebtn=tmq_fetch_array($homebtn);
		$spaththisfile=str_replace('[dcr]',$dcrs,$homebtn[url]);
		$spaththisfile=str_replace('//','/',$spaththisfile);
		$spaththisfile=trim($spaththisfile,'/');
		$homebtn[url]=str_replace('[dcr]',$dcrURL,$homebtn[url]);
		$svpath= $_SERVER[SCRIPT_FILENAME];
		$svpath = pathinfo($svpath);
		$svpath=trim($svpath["dirname"],'/');
		//echo "($spaththisfile!=$svpath)";
		if ($spaththisfile!=$svpath) {
			?><TD style='padding-right: 10px;'><A HREF="<? echo $homebtn[url]?>" target=_top><img src='<?echo $dcrURL?>neoimg/home.png' width=21 height=21 align=absmiddle ALT="<? echo getlang("˹����ѡ�ͧ�س::l::Your main menu") ." : ".getlang($homebtn[name]);?>" border=0></A></TD><?
		}
	}
	if ( $PHP_SELF !="/$dcr/library/mainadmin.php"	) {
?>

	<TD><img src='<?echo $dcrURL?>neoimg/media/roundedge-gray-left.png'></TD>
	<TD background='<?echo $dcrURL?>neoimg/media/roundedge-gray-right.png' style="background-repeat: no-repeat; background-position: top right; padding-right: 10px;padding-left: 4px;">
<a  href="/<?  echo "$dcr"; ?>/library/mainadmin.php" style="color:white;font-size:14px;font-weight:bold"><? echo getlang("������ѡ::l::Menu"); ?></a> 
</TD>
<?
}	
?>
	<TD >&nbsp;</TD><?
	if (library_gotpermission("circulation")) {
?>
	<TD><img src='<?echo $dcrURL?>neoimg/media/roundedge-blue-left.png'></TD>
	<TD background='<?echo $dcrURL?>neoimg/media/roundedge-blue-right.png' style="background-repeat: no-repeat; background-position: top right; padding-right: 10px;padding-left: 4px;">
<a  href="/<?  echo "$dcr"; ?>/circulation/" style="color:white;font-size:14px;font-weight:bold"><? echo getlang("��ԡ������׹::l::Circulations"); ?></a> 
</TD>
	<TD >&nbsp;</TD>
	<?
}	
?>
	<TD ><img src='<?echo $dcrURL?>neoimg/media/roundedge-red-left.png'></TD>
	<TD background='<?echo $dcrURL?>neoimg/media/roundedge-red-right.png' style="background-repeat: no-repeat; background-position: top right;padding-right: 10px;padding-left: 4px;">
<a  href="/<?  echo "$dcr"; ?>/library/logout.php"  style="color:white;font-size:14px;font-weight:bold;"><? echo getlang("�͡�ҡ�к�::l::Logout"); ?></a>

</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>


</td></tr>  
  </table>
<?
}
?>