<?
function stathist_add($tbl,$id,$det) {
$tbl=addslashes($tbl);
$id=addslashes($id);
$det=addslashes($det);

 $tbl="stathist_$tbl";
 $dat=date("d");
 $mon=date("m");
 $yea=date("Y");
 $now=time();

 		tmq("insert into $tbl set 
		dat='$dat' ,
		 mon='$mon' ,
		  yea='$yea' ,
			 head='$id' ,
			 foot='$det' ,
			 dt='$now' 
		");
}
?>