<?
$tbmn="width=100% cellpadding=2 cellspacing=1
bgcolor=777777";
$tdmn="bgcolor=white
onmouseover=\"this.style.backgroundColor='#e5e5e5' \"
onmouseout=\"this.style.backgroundColor='white' \"
onmousedown=\"this.style.backgroundColor='orange' \"
"
?>