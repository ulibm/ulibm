<?
function form_pickdate_str($formname) {
	global $thaimonstr;
	eval("global $$formname"."_dat;
	global $$formname"."_mon;
	global $$formname"."_yea;

	global $$formname"."_hou;
	global $$formname"."_min;
	global $$formname"."_sec;

	\$dt_dat = $$formname"."_dat;
	\$dt_mon =  $$formname"."_mon;
	\$dt_yea =  $$formname"."_yea;

	\$dt_hou =  $$formname"."_hou;
	\$dt_min =  $$formname"."_min;
	\$dt_sec =  $$formname"."_sec;");

	$str="";
	if ($dt_dat=="") {
		$str.= " �ء�ѹ ";
	} else {
		$str.= " �ѹ��� $dt_dat ";
	}
	if ($dt_mon=="") {
		$str.= " �ء��͹ ";
	} else {
		$str.= " ��͹ ".$thaimonstr[$dt_mon]." ";
	}
	if ($dt_yea=="") {
		$str.= " �ء�� ";
	} else {
		$str.= " �� $dt_yea ";
	}
	return $str;
}
?>