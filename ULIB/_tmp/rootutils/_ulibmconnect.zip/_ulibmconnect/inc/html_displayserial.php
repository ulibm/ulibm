<?
function html_displayserial($ID,$item = "",$serialmode="box") {
	global $dcrs;
	global $dcrURL;
	global $thaimonstr;
	global $_TBWIDTH;

if ($serialmode=="") {
	$serialmode="list";
}

	pagesection(getlang("��¡���������ʹ�� (������)::l::Items (serial)"));
?><CENTER><? echo getlang("��Ẻ::l::View mode");?>:
<A HREF="<? echo $dcrURL;?>dublin.php?ID=<? echo $ID?>&serialmode=box" class=a_btn><? echo getlang("���ͧ::l::Box");?></A>
<A HREF="<? echo $dcrURL;?>dublin.php?ID=<? echo $ID?>&serialmode=list" class=a_btn><? echo getlang("��¡��::l::List");?></A></CENTER><?
if ($serialmode=="box") {
?><TABLE align=center width=<?echo $_TBWIDTH+10?> cellpadding=0 cellspacing=0>
<TR>
	<TD><?
$MID=$ID;
$boxrow=6;
	$sb1="SELECT *  FROM media_mid where pid='$MID' ";	
			$sb1="$sb1 group by jenum_1,jenum_2,jenum_3,jenum_4,jenum_5,jenum_6,calln";
	$tdwidth=floor($_TBWIDTH/$boxrow)-10;
	if ($tdwidth<100) {
		 $tdwidth=100;
	}
	$sb1.=" order by jchrono_1 , jchrono_2 , jchrono_3 ,jenum_1 ,jenum_2 ,jenum_3,jenum_4,jenum_5,jenum_6 ";
  $sql1 ="$sb1" ; 

	$result = tmq($sql1,false);
	
									


while($row = tmq_fetch_array($result)) {
	$sets=tmq("select * from media_mid where pid='$MID' and jenum_1='$row[jenum_1]' and jenum_2='$row[jenum_2]' and jenum_3='$row[jenum_3]' and jenum_4='$row[jenum_4]' and jenum_5='$row[jenum_5]' and jenum_6='$row[jenum_6]' and calln='$row[calln]' ");
	$thisnum=tmq_num_rows($sets);
	$setstp=tmq_fetch_array($sets);
	$thiscalln=trim(serial_get_volstr($setstp[id]));
	if ($thiscalln=="") {
		$thiscalln="<I>no call number</I>";
	}
	?><div style="display: block; border: 1px solid #633F3D; width: <? echo $tdwidth;?>; height:130; margin: 2 2 2 2; float: left; padding: 2 2 2 2; overflow:hidden">
	<?
	$stat=tmq("select * from media_mid where pid='$MID' and jenum_1='$row[jenum_1]' and jenum_2='$row[jenum_2]' and jenum_3='$row[jenum_3]' and jenum_4='$row[jenum_4]' and jenum_5='$row[jenum_5]' and jenum_6='$row[jenum_6]' and calln='$row[calln]' and bcode<>'' and jpublicnote not like '%bound%'");
	if (tmq_num_rows($stat)!=0) {
		echo "<div style=\"display: block: height:20; width: 100%; background-color:#CFECCE;text-align: center;\">ARRIVED</div>";
		$numitems=tmq_num_rows($stat);
	} else {
		$stat=tmq("select * from media_mid where pid='$MID' and jenum_1='$row[jenum_1]' and jenum_2='$row[jenum_2]' and jenum_3='$row[jenum_3]' and jenum_4='$row[jenum_4]' and jenum_5='$row[jenum_5]' and jenum_6='$row[jenum_6]' and bcode='' and calln='$row[calln]' and jnonpublicnote like '%expected%' ");
		if (tmq_num_rows($stat)!=0) {
			$dsped=true;
			echo "<div style=\"display: block: height:20; width: 100%; background-color:#EECCCC;text-align: center;\">EXPECTED</div>";
		}
		$stat=tmq("select * from media_mid where pid='$MID' and jenum_1='$row[jenum_1]' and jenum_2='$row[jenum_2]' and jenum_3='$row[jenum_3]' and jenum_4='$row[jenum_4]' and jenum_5='$row[jenum_5]' and jenum_6='$row[jenum_6]' and bcode='' and calln='$row[calln]' and (jnonpublicnote like '%late%' or jnonpublicnote like '%wait%'  or jnonpublicnote like '%pend%' )");
		if (tmq_num_rows($stat)!=0) {
			$dsped=true;
			echo "<div style=\"display: block: height:20; width: 100%; background-color:#E6CDED;text-align: center;\">LATE</div>";
		}

		$stat=tmq("select * from media_mid where pid='$MID' and jenum_1='$row[jenum_1]' and jenum_2='$row[jenum_2]' and jenum_3='$row[jenum_3]' and jenum_4='$row[jenum_4]' and jenum_5='$row[jenum_5]' and jenum_6='$row[jenum_6]' and bcode<>'' and calln='$row[calln]' and (jpublicnote like '%bound%')");
		if (tmq_num_rows($stat)!=0) {
			$dsped=true;
			echo "<div style=\"display: block: height:20; width: 100%; background-color:#FFBBBB;text-align: center;\">BOUND</div>";
		}
		if ($dsped!=true) {
			echo "<div style=\"display: block: height:20; width: 100%; background-color:#DCDEDC;text-align: center;\">-</div>";
		}
	}
	?><FONT class=smaller2><? echo $thiscalln; ?></FONT><?
		$sets=tmq("select distinct place from media_mid where pid='$MID' and jenum_1='$row[jenum_1]' and jenum_2='$row[jenum_2]' and jenum_3='$row[jenum_3]' and jenum_4='$row[jenum_4]' and jenum_5='$row[jenum_5]' and jenum_6='$row[jenum_6]' and calln='$row[calln]' ");
	if (tmq_num_rows($sets)!=0) {
		echo "<FONT class=smaller2><BR><nobr><FONT class=smaller2 color=darkblue>".getlang("ʶҹ���::l::Shelves").":</FONT></nobr> ";
		while ($setsr=tmq_fetch_array($sets)) {
			echo get_itemplace_name($setsr[place],'&gt;');
		}
		echo "</FONT>";
	}
	$chain=tmq("select id from chainerlink where fromid='$ID' and frommid='$row[id]' ",false);
	//echo tmq_num_rows($chain);
	$chainc=tmq_num_rows($chain);
	if (tmq_num_rows($chain)!=0) {
		echo "<div style='display:block; width: 100%; margin-top:10px; text-align:center; background-color: #F4FAFF' ><a href='$dcrURL/dublin.serialchainerlist.php?ID=$ID&mid=$row[id]' rel='gb_page_fs[]' class=smaller2>".getlang("�մ�ê�������� $chainc ��¡��::l::Indexes ($chainc)")."</a></div>";
	}
	?></div><?
} // each row
 ?>
</div></TD>
</TR>
</TABLE><?
	 
}
if ($serialmode=="list") {
?>
<blockquote> 
<? 
  $sql2 ="SELECT *  FROM media_mid where pid=$ID and bcode<>'' order by inumber,jenum_1,jenum_2,jenum_3,jenum_4,jenum_5,jenum_6,jchrono_1,jchrono_2,jchrono_3,id"; 
//echo $sql2; 
$r2 = tmq($sql2);

echo "<table border=1 bordercolor=666666 cellpadding=0 width='$_TBWIDTH' align=center 
bgcolor=666666 cellspacing=1 class=table_border >
<Tr >
	<td width=5% class=table_head><nobr>".getlang("�ӴѺ���::l::No.")."</B></td>
	<td align=center width=10% class=table_head><nobr>".getlang("������::l::Type")."</B></td>
 	<td align=center width=15% class=table_head><nobr>".getlang("�Ţ���¡::l::CallNumber")."</B>/<nobr>".getlang("������::l::Barcode")."</B></td>
	<td align=center width=15% class=table_head><nobr>".getlang("ʶҹ���::l::Place")."</B></td>
  <td align=center width=15% class=table_head>".getlang("ʶҹ�::l::Status")."</B></td>
</tr>";
//echo $mMID;
$i2=1;
	//while (list(,$row2) = each($mMID)) {
while ($r = tmq_fetch_array($r2)) {
	$mMID=$r[bcode];
////ishide also on html_displayserial() start
if (loginchk_lib("check")==false) {
	$rectype=tmq("select * from media_type where code='$r[RESOURCE_TYPE]'  ");
	$rectype=tmq_fetch_array($rectype);
	if ($rectype[ishide]=='yes') {
		continue;
	}
	$midstat=tmq("select * from media_mid_status where code='$r[status]'  ");
	$midstat=tmq_fetch_array($midstat);
	if ($midstat[ishide]=='yes') {
		continue;
	}
}
////ishide also on html_displayserial() end	  $mMID=$r[bcode];
//  echo "/ /$row2/ /";
if ($r[bcode]==$item) {
	$bg=" style='background-color:#FFE4CA' ";
	$star="**";
} else {
	$bg=" style='background-color:#FFFFFF'";
	$star="";
}


echo "<tr $bg><td class=table_td align=right>$i2.</td>
	<td class=table_td  align=center><img border=0 width=48 height=48 src='";
	if ($r[status]=="reservmat") {
		$usecode="reservmat";
	} else {
		$usecode=$r[RESOURCE_TYPE];
	}
	if (file_exists("$dcrs/_tmp/mediatype/$usecode.png")==true) {
		echo "$dcrURL/_tmp/mediatype/$usecode.png";
	} else {
		echo "$dcrURL/_tmp/mediatype.png";
	}
	echo "' > <BR><FONT class=smaller2>".get_media_type($usecode)."</FONT>";
if ($r[status]!="") {
	echo " <BR> <FONT class=smaller2 COLOR='#002F5E'>".getlang("ʶҹ�::l::Status")."=".get_mid_status($r[status])."</FONT>";
}
	echo "</td>";
$t02=marc_getserialcalln($r[id]);;
echo "<td  class=table_td align=left $bg> $t02$star <BR><FONT class=smaller2>&nbsp;&nbsp;Barcode: $r[bcode] </FONT></td>		";
echo "	<td class=table_td align=center $bg><a href='$dcrURL"."itemplaces.php?focuscalln=".urlencode($t02)."&focusshf=$r[place]' target=_blank class=smaller>";
echo get_itemplace_name($r[place],'<BR>&gt;');
echo "</a> </td>";

$ecstat=bitem_get_checkoutstr($mMID);
 echo "<TD $bg class=table_td align=center>";
 echo $ecstat;
 html_displayrqitem($mMID,$r[place]);
	$hrs=getval("config","timetocirputtoshelf");

  if (floor($r[lastcheckin]+(60*60*$hrs))>time()) {
  	 echo "<br /><font color='#cc3333'><i>*";
  	 echo getlang("����Ѻ�׹::l::At circulation desk");
  	 echo "</i></font>";
  }
  //////////start is midstatus hide  also on html_displayserial() 
$midstat=tmq("select * from media_mid_status where code='$r[status]'  ");
$midstat=tmq_fetch_array($midstat);
if ($midstat[ishide]=='yes') {
	echo "<BR><FONT class=smaller2>".getlang("��¡�ù��١��͹�ҡ�����::l::This item hidden from users")."</FONT>";
}
//////////end is midstatus hide  also on html_displayserial() 
 echo "</td>";
$i2 +=1;
echo "</tr>";

bitem_get_chaininfo($ID,$r[id]);

}
//echo "$i2";

if ($i2==1) {
  echo "<tr	><td colspan=7 align=center  class=table_td>- ".getlang("��辺������::l::No item found")." - </td></tr>";
}
echo "</table>";
           ?>
</blockqoute>
 <?
}
}
?>