<?
function ymd_mkdt($XXdat,$XXmon,$XXyea) {
	$res= mktime(0, 0, 0, $XXmon, $XXdat, $XXyea);
	if ($res==false) {
		 die("ymd_mkdt error (mktime(0, 0, 0, $XXmon, $XXdat, $XXyea);)");
	} 
	return $res;
}
?>