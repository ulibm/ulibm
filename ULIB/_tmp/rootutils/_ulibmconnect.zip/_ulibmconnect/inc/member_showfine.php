<?
function member_showfine($useradminid2) {
	global $dcr;
	global $isatcirculation;
	global $_TBWIDTH;
	?><BR><?
	pagesection("��¡�ä�һ�Ѻ::l::Fine","narrow");
?>
	<TABLE cellpadding = 1 cellspacing = 0 width="<? echo $_TBWIDTH;?>" align=center border = 1 class=table_border>
		<TR bgcolor = f2f2f2>
			<TD width = 10% align = center class=table_head><? echo getlang("�ӴѺ���::l::No."); ?></TD>
			<TD align = center class=table_head><? echo getlang("��һ�Ѻ::l::Fine"); ?></TD>
			<TD align = center class=table_head><? echo getlang("�ӹǹ::l::Fine"); ?></TD>
		</TR>
	<?
		$sql33="SELECT *  FROM fine where memberId='$useradminid2' and isdone='no'";
		$result33=tmq($sql33);
		$NRow33=tmq_num_rows($result33);
		//echo "$NRow33";
		$ix=0;
		$allfine=0;
		while ($row33=tmq_fetch_array($result33))
			{
			$topic = $row33[topic];
			$lib=$row33[lib];
			$fine=$row33[fine];
			$allfine+=$row33[fine];
			$ix++;
	?>
			<TR>
				<TD class=table_td><?
						echo $ix;
					?>
					.</TD>
				<TD class=table_td><?
				echo $topic;
			?></B></TD>
				<TD class=table_td><?
						echo number_format($fine);
					?></TD>
			</TR>
	<?
			}
		//echo "[[[ $allfine --]]]]";
		if ($allfine != 0 || $NRow33!=0)
			{
			echo "<tr><td align=right colspan=3  class=table_td><B style='color:red'>".getlang("���::l::Total")." " . number_format($allfine) . "  ".getlang("�ҷ::l::Baht")."</td></tr>";
				if (loginchk_lib("check")==true) {
					echo "<tr><td align=right colspan=3  class=table_td>".
					getlang("�դ�һ�Ѻ �ҡ��ͧ��ê��Ф�һ�Ѻ::l::Some fine not processed to process");
					if ($isatcirculation=="yes") {
						echo " <a href='working.fine.php?memberbarcode=$useradminid2'  class=a_btn>".getlang("��ԡ�����::l::click here")."</a>";
					} else {
						echo " <a href='/$dcr/circulation/index.php?loadfine=$useradminid2' target=_top class=a_btn>".getlang("��ԡ�����::l::click here")."</a>";
					}
					echo "</td></tr>";

				}
			} else {
				echo "<tr><td align=center colspan=3  class=table_td>".
				getlang("�������¡�ä�һ�Ѻ::l::No fine.")."</td></tr>";
			}
			$crule=tmq("select * from member where UserAdminID='$useradminid2' ",false);
			$crule=tmq_fetch_array($crule);
			$crule=tmq("select * from member_type where type='$crule[type]' ",false);
			$crule=tmq_fetch_array($crule);
			echo "<tr><td align=center colspan=3  class=table_td>";
			$crule[maxfine]=floor($crule[maxfine]);
			if ($crule[maxfine]==0) {
				echo getlang("��Ҫԡ������ ::l::Member type ").getlang($crule[descr]);
				echo getlang(" �������ö�����ʴ����ʹ���� �ҡ��ҧ��һ�Ѻ::l:: Cannot checkout items with fine.");
			} else {
				echo getlang("��Ҫԡ������ ::l::Member type ").getlang($crule[descr]);
				echo getlang(" ��ҧ��һ�Ѻ���٧�ش  ".number_format($crule[maxfine])." �::l:: can checkout item when have fine lower ".number_format($crule[maxfine])." �.");
			}
			echo "</td></tr>";
	?>
	</TABLE>
<?
}
?>