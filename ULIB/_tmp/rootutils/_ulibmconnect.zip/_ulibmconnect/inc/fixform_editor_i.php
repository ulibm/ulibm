<?
function fixform_editor_i($val,$tb) {
	global $fftmode;
	global $useradminid;
	global $fixform_editor_i_colorpicker_initialized;
	global $ffe_limitsql;
	global $_MSTARTY;
	global $_MENDY;
	global $dcrURL;
	global $ffteditid; //first use on globalupload:: && singlefile


	//printr($val);

		$kid="ffdat[$val[field]]";
	if ($val[fieldtype]=="addcontrol")	 {
		if ($fftmode=="add") {
			echo "<INPUT TYPE='hidden' NAME='$kid' value='$val[defval]' >";
			return;
		}
		if ($fftmode=="edit") {
			return;
		}
	}
	$kid_ID=$kid."-".randid();
	$kid_IDjs=str_remspecialsign($kid_ID);
	?>
		<TR>
		<TD class=table_head><LABEL FOR='<? echo $kid_ID;?>'><? echo getlang($val[text])?></LABEL></TD>
		<TD class=table_td> <?
	if ($val[fieldtype]=="color")	 {
		$val[defval]=trim($val[defval],'#');
		if ($fixform_editor_i_colorpicker_initialized=="") {
			$fixform_editor_i_colorpicker_initialized="yes";
			?> <link rel="stylesheet" href="<? echo $dcrURL?>js/colorpicker/COLOURloversColorPicker.css" type="text/css" media="all" />
<script type="text/JavaScript" src="<? echo $dcrURL?>js/colorpicker/COLOURloversColorPicker.php?fake=colpicker.js"></script>
<div id="CLCP" class="CLCP"></div>
<?}?>
<input name="<?echo $kid?>" ID="<?echo $kid_ID?>" style="width: 100px; border-left-width:15px; border-style:solid;" maxlength="6" value="<? echo $val[defval]?>" />
<a href="JavaScript:_whichField='<?echo $kid_ID?>';_CLCPinitHex='<? echo $val[defval]?>';CLCPshowPicker({_hex: document.getElementById('<?echo $kid_ID?>').value});"><? echo getlang("���͡��::l::Pick color");?></a>

<script type="text/JavaScript">
  _whichField = "<?echo $kid_ID?>";
  CLCPHandler = function(_hex) {
    // This function gets called by the picker when the sliders are being dragged. The variable _hex contains the current hex value from the picker
    // This code serves as an example only, here we use it to do three things:
    // Here we simply drop the variable _hex into the input field, so we can see what the hex value coming from the picker is:
        document.getElementById(_whichField).value = _hex;
    // Here is where we color the BG of a div to preview the color:
		document.getElementById(_whichField).style.borderColor = ("#" + _hex);
    // Giving you control over this function really puts the reigns in your hands. Rewrite this function as you see fit to really take control of this color picker.
  }
  // Settings:
  _CLCPdisplay = "none"; // Values: "none", "block". Default "none"
  _CLCPisDraggable = true; // Values: true, false. Default true
  _CLCPposition = "absolute"; // Values: "absolute", "relative". Default "absolute"
  _CLCPinitHex = "<? echo $val[defval]?>"; // Values: Any valid hex value. Default "ffffff"
  CLCPinitPicker();
</script>

<?
		/*
?>
		<SELECT NAME="<?echo $kid?>" ID='<?echo $kid_ID?>'>
			<?
		$coldata=explode(',','#FFFFFF,#000000,#003300,#006600,#009900,#00CC00,#00FF00,#000033,#003333,#006633,#009933,#00CC33,#00FF33,#000066,#003366,#006666,#009966,#00CC66,#00FF66,#000099,#003399,#006699,#009999,#00CC99,#00FF99,#0000CC,#0033CC,#0066CC,#0099CC,#00CCCC,#00FFCC,#0000FF,#0033FF,#0066FF,#0099FF,#00CCFF,#00FFFF,#330000,#333300,#336600,#339900,#33CC00,#33FF00,#330033,#333333,#336633,#339933,#33CC33,#33FF33,#330066,#333366,#336666,#339966,#33CC66,#33FF66,#330099,#333399,#336699,#339999,#33CC99,#33FF99,#3300CC,#3333CC,#3366CC,#3399CC,#33CCCC,#33FFCC,#3300FF,#3333FF,#3366FF,#3399FF,#33CCFF,#33FFFF,#660000,#663300,#666600,#669900,#66CC00,#66FF00,#660033,#663333,#666633,#669933,#66CC33,#66FFCC,#660066,#663366,#666666,#669966,#66CC66,#66FF66,#660099,#663399,#666699,#669999,#66CC99,#66FF99,#6600CC,#6633CC,#6666CC,#6699CC,#66CCCC,#66FFCC,#6600FF,#6633FF,#6666FF,#6699FF,#66CCFF,#66FFFF,#990000,#993300,#996699,#999900,#99CC00,#99FF00,#990033,#993333,#996633,#999933,#99CC33,#99FF33,#990066,#993366,#996666,#999966,#99CC66,#99FF66,#990099,#993399,#996699,#999999,#99CC99,#99FF99,#9900CC,#9933CC,#9966CC,#9999CC,#99CCCC,#99FFCC,#9900FF,#9933FF,#9966FF,#9999FF,#99CCFF,#99FFFF,#CC0000,#CC3300,#CC6600,#CC9900,#CCCC00,#CCFF00,#CC0033,#CC3333,#CC6633,#CC9933,#CCCC33,#CCFF33,#CC0066,#CC3366,#CC6666,#CC9966,#CCCC66,#CCFF66,#CC0099,#CC3399,#CC6699,#CC9999,#CCCC99,#CCFF99,#CC00CC,#CC33CC,#CC66CC,#CC99CC,#CCCCCC,#CCFFCC,#CC00FF,#CC33FF,#CC66FF,#CC99FF,#CCCCFF,#CCFFFF,#FF0000,#FF3300,#FF6600,#FF9900,#FFCC00,#FFFF00,#FF0033,#FF3333,#FF6633,#FF9933,#FFCC33,#FFFF33,#FF0066,#FF3366,#FF6666,#FF9966,#FFCC66,#FFFF66,#FF0099,#FF3399,#FF6699,#FF9999,#FFCC99,#FFFF99,#FF00CC,#FF33CC,#FF66CC,#FF99CC,#FFCCCC,#FFFFCC,#FF00FF,#FF33FF,#FF66FF,#FF99FF,#FFCCFF,#FFFFFF,#DADADA,#C3C3C3,#A2A2A2,#838383,#616161,#3C3C3C,#1D1D1D');
		reset ($coldata); 
				while (list ($lkey, $lval) = each ($coldata)) { 
					$select="";
					if ($lval==$val[defval]) {
						$select=" selected ";
					}
				   echo "<OPTION VALUE='$lval' $select style='background-color:$lval;'>$lval"; 
				} 	
		?>
		</SELECT><?
			*/
	}
	if ($val[fieldtype]=="frm_itemplace")	 {
		frm_itemplace($kid,$val[defval],"yes","",$kid_ID);
	}	
	if ($val[fieldtype]=="frm_restype")	 {
		frm_restype($kid,$val[defval],"YES",$kid_ID);
	}	
	if ($val[fieldtype]=="text")	 {
		$val[defval]=str_replace('"','&quot;',$val[defval]);
		$val[defval]=stripslashes($val[defval]);
		echo "<INPUT TYPE='text' NAME='$kid' value=\"$val[defval]\" size=35 ID='$kid_ID'>";
	}	
	if ($val[fieldtype]=="yesno")	 {
		$val[defval]=str_replace('"','&quot;',$val[defval]);
		$val[defval]=stripslashes($val[defval]);
		if (strtoupper($val[defval])=="YES") {
			$_localtmp_y=" checked ";
			$_localtmp_n="";
		} else {
			$_localtmp_y="";
			$_localtmp_n=" checked ";
		}
		echo "<label style='color: darkgreen;'><INPUT TYPE='radio' NAME='$kid' value='YES'  ID='$kid_ID' $_localtmp_y> ".getlang("��::l::Yes")."</label>";
		echo " &nbsp; ";
		echo "<label style='color: darkred;'><INPUT TYPE='radio' NAME='$kid' value='NO' $_localtmp_n> ".getlang("�����::l::No")."</label>";
		//echo "<INPUT TYPE='text' NAME='$kid' value=\"$val[defval]\" size=35 ID='$kid_ID'>";
	}	
	if ($val[fieldtype]=="html")	 {
		html_htmlareajs();
		$val[defval]=stripslashes($val[defval]);
		echo "<TEXTAREA NAME='$kid' style=\"width:500px; height: 400px;\"  ID='$kid_ID'>$val[defval]</TEXTAREA>";
		html_htmlarea_gen("$kid");

		$tmpchk=substr($val[addon],0,14);
		if ($tmpchk=="globalupload::") {
			$globaluploadkey=substr($val[addon],14);
			if ($globaluploadkey=="") {
				$globaluploadkey="$tb-$ffteditid";
			}
			//echo "key=$globaluploadkey$fftmode;";
			if ($fftmode=="add") {
				$globaluploadkey="TEMP";
			}
			frm_globalupload($globaluploadkey,$kid);
		}
	}	
	if ($val[fieldtype]=="year")	 {
		$tmptype="";
		for ($i=$_MSTARTY;$i<=$_MENDY;$i++) {
			$tmptype.=",$i";
		}
		$tmptype=trim($tmptype,',');
		$val[fieldtype]="list:$tmptype";
	}	
	if ($val[fieldtype]=="readonlytext")	 {
		echo "<INPUT TYPE='hidden' NAME='$kid' value='$val[defval]' size=35 ID='$kid_ID'> $val[defval]";
	}	
	if ($val[fieldtype]=="password")	 {
		//value='$val[defval]' 
		echo "<INPUT TYPE='hidden' NAME='$kid' value='passdata::passdata_$val[field]'>";
		echo "<INPUT TYPE='password' NAME='passdata_$val[field]' size=20 ID='$kid_ID'> ".getlang("�������ҧ�ҡ����ͧ�������¹::l::Left blank to unchange");
	}
	if ($val[fieldtype]=="longtext")	 {
		$val[defval]=str_replace('"','&quot;',$val[defval]);
		$val[defval]=stripslashes($val[defval]);
		$val[defval]=str_replace('</TEXTAREA>','&lt;/TEXTAREA>',$val[defval]);
		echo "<TEXTAREA NAME='$kid' ROWS=4 COLS=40 ID='$kid_ID'>$val[defval]</TEXTAREA>";
	}
	if ($val[fieldtype]=="switchsingle")	 {
		if ($val[defval]=="yes") {
			$defyes="checked";
			$defno=" ";
		} else {
			$defyes=" ";
			$defno="checked";
		}
		echo "<label style='color: darkgreen; font-weight:bold;'><INPUT TYPE='radio' NAME='switchsingle_$val[field]' value='yes' $defyes style='border-width: 0' ID='$kid_ID'> ".getlang("��::l::Yes")."</label> &nbsp;";
		echo "<label style='color: darkred; font-weight:bold;'><INPUT TYPE='radio' NAME='switchsingle_$val[field]' value='no' $defno style='border-width: 0'> ".getlang("���::l::No")."</label> &nbsp;";
		echo "<INPUT TYPE='hidden' NAME='$kid' value='switchsi::switchsingle_$val[field]'>";

	}
	if ($val[fieldtype]=="special_libmenu")	 {
		$callpdb=tmq_dump("library_modules_cate","code","name");
		//printr($callpdb);
		$cdefault=tmq("select * from library_modules where code='$val[defval]' ",false);
?>
		<SELECT NAME="<?echo $kid?>" ID='<?echo $kid_ID?>'>
			<?
			if (tmq_num_rows($cdefault)==1) {
				$cdefault=tmq_fetch_array($cdefault);
			   echo "<OPTION VALUE='".$val[defval]."' selected>" .getlang($callpdb[$cdefault[nested]])." ->".getlang($cdefault[name]); 
			}
			   echo "<OPTION VALUE='' >" . getlang("����˹�::l::Not specific");
			$call=tmq("select * from library_modules where nested<>'' and url<>'' order by nested",false);
			while ($callr=tmq_fetch_array($call)) { 
				//getlang($callpdb[$callr[nested]])
			   echo "<OPTION VALUE='".$callr[code]."'>".getlang($callpdb[$callr[nested]])." ->".getlang($callr[name]); 
			} 	
		?>
		</SELECT><?	}
	if ($val[fieldtype]=="number")	 {
		echo "<INPUT TYPE='text' NAME='$kid' value='$val[defval]' size=20 style='text-align:right' ID='$kid_ID' >";
	}
	if ($val[fieldtype]=="date")	 {
		if (floor($val[defval])==0) {
			$val[defval]=1;
		}
		form_pickdate("datdata_$val[field]",$val[defval]);
		echo "<INPUT TYPE='hidden' NAME='$kid' value='datedata::datdata_$val[field]'>";
	}
	if ($val[fieldtype]=="datetime")	 {
		if (floor($val[defval])==0) {
			$val[defval]=1;
		}
		form_pickdatetime("datdata_$val[field]",$val[defval]);
		echo "<INPUT TYPE='hidden' NAME='$kid' value='datedata::datdata_$val[field]'>";
	}
	if ($val[fieldtype]=="autotime")	 {
		echo "<INPUT TYPE='hidden' NAME='$kid' value='".time()."'>".ymd_datestr(time());
	}
	if ($val[fieldtype]=="autoofficer")	 {
		echo "<INPUT TYPE='hidden' NAME='$kid' value='$useradminid'>".get_library_name($useradminid);
	}
	if ($val[fieldtype]=="file")	 {
		echo "<INPUT TYPE='file' NAME='$kid' value=''>";
	}
	//printr($ffteditid);
	if ($val[fieldtype]=="singlefile") {
		if ($ffteditid=='') {
			$ffteditid="TEMP-$useradminid";
		}
		?>
		<iframe width=100% height=25 src="<? echo $dcrURL;?>fft_upload.php?table=<? echo $tb?>&fid=<? echo $val[field]?>&keyid=<? echo $ffteditid; ?>" FRAMEBORDER="no" BORDER=0 scrolling=no></iframe>
		<?
	}
	if ($val[fieldtype]=="autorun")	 {
		if ($fftmode=="edit") {
			$defvaldsp=substr("00000000000$val[defval]",-6);
			echo "<INPUT TYPE='hidden' NAME='$kid' value='$val[defval]'> <B>$defvaldsp</B>";
		} else {
			$chkold=tmq("select * from $tb where $ffe_limitsql order by floor($val[field]) desc limit 1",false);
			$chkold=tmq_fetch_array($chkold);
			$chkold=floor($chkold[$val[field]])+1;
			$chkolddsp=substr("00000000000$chkold",-6);
			echo "<INPUT TYPE='hidden' NAME='$kid' value='autoruni::'> <B>$chkolddsp</B>";
		}
	}
	$tmpchk=substr($val[fieldtype],0,5);
	if ($tmpchk=="list:") {
		$listdat=substr($val[fieldtype],5);
		$listdata=explode(',',$listdat);
		//print_r($listdata);
		$tmpchk=substr($val[addon],0,16);
		//echo $tmpchk;
		?>
		<SELECT NAME="<?echo $kid?>" ID='<?echo $kid_ID?>' <?
		if ($tmpchk=="list-previewimg:") {
			echo " onchange=\"ffedit_listpreview_$kid_IDjs(this)\" ";
			$listpreviewdata=explode(',',substr($val[addon],16));
		}	
		?>>
			<?
		reset ($listdata); 
				while (list ($lkey, $lval) = each ($listdata)) { 
					$select="";
					if ($lval==$val[defval]) {
						$select=" selected ";
					}
				   echo "<OPTION VALUE='$lval' $select>$lval"; 
				} 	
		?>
		</SELECT><?
		if ($tmpchk=="list-previewimg:") {
			if ($listpreviewdata[1]==0) {
				$listpreviewdata[1]=32;
			}
			//printr($listpreviewdata);
			?><div ID="ffedit_listpreviewform_<?echo $kid_IDjs;?>"></div>
			<SCRIPT LANGUAGE="JavaScript">
			<!--
			function ffedit_listpreview_<?echo $kid_IDjs;?>(wh) {
				getobj("ffedit_listpreviewform_<?echo $kid_IDjs;?>").innerHTML="<img src='<? echo $listpreviewdata[0]?>/"+wh.value+"<? echo $listpreviewdata[2]?>' border=1 align=absmiddle width='<? echo $listpreviewdata[1]?>'>"
			}
			ffedit_listpreview_<?echo $kid_IDjs;?>(getobj("<? echo $kid_ID;?>"));
			//-->
			</SCRIPT>
			<?
		}	

	}
	$tmpchk=substr($val[fieldtype],0,8);
	if ($tmpchk=="foreign:") {
		$listdat=substr($val[fieldtype],8);
		$listdata=explode(',',$listdat);
		//print_r($listdata);
		?>
		<SELECT NAME="<?echo $kid?>" ID='<?echo $kid_ID?>'>
			<?
			$listdata7a=explode('=',$listdata[7]);
			if ($listdata7a[0]==$val[defval]) {
			   echo "<OPTION VALUE='".$listdata7a[0]."' selected>".getlang($listdata7a[1]); 
			   if ($listdata[6]=="displaykey") {
				echo " (".$listdata7a[0].")";
			   }
			} else {
				$cdefault=aliceos_tmqs("select $listdata[2],$listdata[3] from $listdata[1] where $listdata[2]='$val[defval]' order by $listdata[3]",false,$listdata[0]);
				if (tmq_num_rows($cdefault)==1) {
					$cdefault=tmq_fetch_array($cdefault);
				   echo "<OPTION VALUE='".$val[defval]."' selected>" . getlang($cdefault[$listdata[3]]); 
				}
			}
			if ($listdata[4]=="allowblank") {
				if ($listdata[5]=="") {
					$listdata[5]=getlang("����˹�::l::Not specific");
				}
			   echo "<OPTION VALUE='' >" . $listdata[5]; 
			}
			$call=aliceos_tmqs("select $listdata[2],$listdata[3] from $listdata[1] where $listdata[2]<>'$val[defval]' ",false,$listdata[0]);
			while ($callr=tmq_fetch_array($call)) { 
			   echo "<OPTION VALUE='".$callr[$listdata[2]]."'>".getlang($callr[$listdata[3]]); 
			   if ($listdata[6]=="displaykey") {
				echo " (".$callr[$listdata[2]].")";
			   }
			}
			if ($listdata[7]!="") {
				if ($listdata7a[0]!=$val[defval]) {
				   echo "<OPTION VALUE='".$listdata7a[0]."'>".getlang($listdata7a[1]); 
				   if ($listdata[6]=="displaykey") {
					echo " (".$listdata7a[0].")";
				   }
				}
			}
		?>
		</SELECT><?
	}

	$tmpchk=substr($val[fieldtype],0,7);
	//echo $tmpchk;
	if ($tmpchk=="mappos,") {
		$libsiteid=substr($val[fieldtype],7);
		$tmpshf=tmq("select * from media_place where code='$libsiteid' ");
		$tmpshf=tmq_fetch_array($tmpshf);
		$tmpshf=$tmpshf[main];
		?><INPUT TYPE="text" NAME="<?echo $kid?>" ID='<?echo $kid_ID?>' value="<? echo $val[defval]; ?>"> <A HREF="<? echo $dcrURL?>/_mappospicker.php?libsiteid=<? echo $tmpshf;?>&jsid=<? echo $kid_ID?>"  rel="gb_page_fs[]"  class='a_btn smaller'><?echo getlang("���͡::l::Pick");?></A><?
	}
	if ($val[fieldtype]=="callnpicker") {
		?><INPUT TYPE="text" NAME="<?echo $kid?>" ID='<?echo $kid_ID?>' value="<? echo $val[defval]; ?>"> <A HREF="<? echo $dcrURL?>/_callnpicker.php?jsid=<? echo $kid_ID?>"  rel="gb_page_fs[]"  class='a_btn smaller'><?echo getlang("���͡::l::Pick");?></A><?
	}


	echo " ".getlang($val[descr])?></TD>
	</TR>

	<?
}
?>