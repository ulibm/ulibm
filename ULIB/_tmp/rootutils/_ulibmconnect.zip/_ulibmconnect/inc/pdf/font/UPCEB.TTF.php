<?php
$type='TrueType';
$name='EucrosiaUPCBold';
$desc=array('Ascent'=>449,'Descent'=>-143,'CapHeight'=>443,'Flags'=>32,'FontBBox'=>'[-395 -277 777 849]','ItalicAngle'=>0,'StemV'=>120);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>225,'!'=>266,'"'=>265,'#'=>523,'$'=>474,'%'=>650,'&'=>541,'\''=>174,'('=>357,')'=>357,'*'=>327,'+'=>372,
	','=>237,'-'=>372,'.'=>181,'/'=>382,'0'=>454,'1'=>454,'2'=>454,'3'=>454,'4'=>454,'5'=>454,'6'=>454,'7'=>454,'8'=>454,'9'=>454,':'=>241,';'=>241,'<'=>389,'='=>390,'>'=>389,'?'=>424,'@'=>604,'A'=>469,
	'B'=>434,'C'=>469,'D'=>469,'E'=>434,'F'=>397,'G'=>506,'H'=>506,'I'=>253,'J'=>325,'K'=>506,'L'=>434,'M'=>614,'N'=>469,'O'=>506,'P'=>397,'Q'=>506,'R'=>469,'S'=>361,'T'=>434,'U'=>469,'V'=>469,'W'=>650,
	'X'=>469,'Y'=>469,'Z'=>434,'['=>216,'\\'=>181,']'=>216,'^'=>378,'_'=>325,'`'=>216,'a'=>325,'b'=>361,'c'=>289,'d'=>361,'e'=>289,'f'=>216,'g'=>325,'h'=>361,'i'=>181,'j'=>216,'k'=>361,'l'=>181,'m'=>541,
	'n'=>361,'o'=>325,'p'=>361,'q'=>361,'r'=>289,'s'=>253,'t'=>216,'u'=>361,'v'=>325,'w'=>469,'x'=>325,'y'=>325,'z'=>289,'{'=>256,'|'=>143,'}'=>256,'~'=>338,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>430,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>260,chr(146)=>237,chr(147)=>336,chr(148)=>341,chr(149)=>383,chr(150)=>456,chr(151)=>560,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>225,chr(161)=>423,chr(162)=>411,chr(163)=>429,chr(164)=>463,chr(165)=>463,chr(166)=>484,chr(167)=>342,chr(168)=>378,chr(169)=>464,chr(170)=>405,chr(171)=>433,chr(172)=>575,chr(173)=>578,chr(174)=>430,chr(175)=>437,
	chr(176)=>388,chr(177)=>482,chr(178)=>608,chr(179)=>581,chr(180)=>453,chr(181)=>453,chr(182)=>414,chr(183)=>449,chr(184)=>404,chr(185)=>447,chr(186)=>461,chr(187)=>462,chr(188)=>454,chr(189)=>455,chr(190)=>491,chr(191)=>494,chr(192)=>436,chr(193)=>461,chr(194)=>413,chr(195)=>346,chr(196)=>411,chr(197)=>413,
	chr(198)=>440,chr(199)=>350,chr(200)=>456,chr(201)=>462,chr(202)=>418,chr(203)=>451,chr(204)=>497,chr(205)=>410,chr(206)=>412,chr(207)=>424,chr(208)=>348,chr(209)=>0,chr(210)=>338,chr(211)=>330,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>434,chr(224)=>238,chr(225)=>446,chr(226)=>282,chr(227)=>298,chr(228)=>299,chr(229)=>324,chr(230)=>564,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>510,chr(240)=>478,chr(241)=>504,
	chr(242)=>498,chr(243)=>540,chr(244)=>469,chr(245)=>474,chr(246)=>465,chr(247)=>625,chr(248)=>523,chr(249)=>526,chr(250)=>502,chr(251)=>792,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='cp874';
$diff='130 /.notdef /.notdef /.notdef 134 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 152 /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='UPCEB.TTF.z';
$originalsize=47180;
?>
