<?
class PDF extends FPDF
{


}

?>