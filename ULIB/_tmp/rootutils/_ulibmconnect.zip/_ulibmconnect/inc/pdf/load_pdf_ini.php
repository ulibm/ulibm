<?
function load_pdf_ini($wh) {
	global $dcrs;
	include("$dcrs/inc/pdf/ini.$wh.php");
}
?>