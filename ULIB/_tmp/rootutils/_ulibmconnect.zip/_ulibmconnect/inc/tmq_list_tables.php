<?
function tmq_list_tables($dbname="") {
	////func("tmq_list_tables()");
	global $dcr_dbname;
	if ($dbname=="") {
		$dbname=$dcr_dbname;
	}
	//echo "$dcr_dbname";
	$result = tmq("show tables from $dbname");
	return $result;
}
?>