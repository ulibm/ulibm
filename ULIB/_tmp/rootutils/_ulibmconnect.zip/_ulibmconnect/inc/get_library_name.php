<?
function get_library_name($wh,$mustexist=false) {
  $s=tmq("select * from library where UserAdminID='$wh' ");
  $r=tmq_fetch_array($s);
  if (trim("$r[UserAdminName]")=="") {
	  if ($mustexist==true) {
			html_dialog("Security alert","User not exists [$wh]");
			die;
	  }
  	return "<I><small>".getlang("��辺�������˹�ҷ����ͧ��ش::l::Librarian not found")." $wh</small></I>";
  }
  return getlang($r[UserAdminName]);
}

?>