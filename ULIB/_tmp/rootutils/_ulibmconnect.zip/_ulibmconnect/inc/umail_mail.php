<?
function umail_mail($to,$subj,$body) {
	global $mail_autocc;
	global $email_ini_called;
	$mail_autocc=trim($mail_autocc);
	global $mail_ReturnPath;
	global $mail_Organization;
	global $mail_from;
	global $mail_attatchline;

	global $mail_mailsmtp;
	global $mail_sendmail_path;

	if ($email_ini_called!="yes") {
		die("Please include inc/email/ini.php before call umail_mail(); ");
	}
	$res="";
	$body.="
$mail_attatchline";

	$headers = "From: $mail_from" . "\r\n" .
    "Reply-To: $mail_from";
	if ($mail_autocc!="") {
		$headers .="Bcc: $mail_autocc";
	}
	if (mail($to, $subj, $body,$headers)) {
		$res="success";
	} else {
		$res="error";
	} 
	filelogs("umail",$to.$subj.$body.$headers,"umail");
	return $res;
	/*,"Return-Path: $mail_ReturnPath
From: $mail_from
To: $to
Organization: $mail_Organization
"*/
}
?>