<?
function frm_itemplace($inputname,$defplace="",$optionall="",$placetype="book",$JSID="") {
	global $LIBSITE;
?>
<SELECT NAME="<?
echo $inputname;	
?>" ID="<?echo $JSID;?>">
<?
if ($optionall=="yes") {
	echo "<option value=''>".getlang("�ʴ�������::l::Show all")."</option>";
}

$sm=tmq("select * from library_site order by name");
while ($rm=tmq_fetch_array($sm)) {
 echo "<optgroup label='".getlang($rm[name])."'>";
$s=tmq("select * from media_place where main='$rm[code]' order by name");

while ($r=tmq_fetch_array($s)) {
	$sl="";
	if ($defplace!="null") {
		if ($defplace!="") {
			if ("$r[code]"=="$defplace") {
				$sl="selected";
			}
		} else {
			if ($r[main]==$LIBSITE) {
				if ($r[isdef]=="YES" && $placetype=="book") {
					$sl="selected";
				}
				if ($r[isdefserial]=="YES" && $placetype=="serial") {
					$sl="selected";
				}
			}
		}
	}
	echo "<option value='$r[code]' $sl>".getlang($r[name])."($r[code]) </option>";
}

///
 echo "</optgroup>";
}
?>
</SELECT>
<?
}?>