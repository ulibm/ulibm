<?
function form_root_login() {
		global $dcrURL;
		global $dcr;
		head();
		redir($dcrURL,75);
?>
<TABLE width=700 height= 260 align=center border=0 cellpadding=0 cellspacing=0
background="/<? echo $dcr;?>/neoimg/formlogin_root.png">
<FORM METHOD=POST ACTION="/<? echo $dcr;?>/root/login.php">
<TR>
	<TD valign=middle style="padding-right: 100px;">

	<TABLE align=right>
<TR>
	<TD bgcolor="#840000" style="font-size: 18px; font-weight: bold; color: #FF8000" align=center colspan=2><? echo getlang("��سһ�͹��͡�Թ������ʼ�ҹ::l:: Enter login and password "); ?></TD>
</TR>
	<TR>
		<TD><B><? echo getlang("������͡�Թ::l::Loginid"); ?></B></TD>
		<TD>: <input ID = "FC" type = "text" name = "useradminidx" autocomplete=off>
<SCRIPT LANGUAGE = "JavaScript">
<!--
getobj('FC').focus()
          //-->
</SCRIPT></TD>
	</TR>
	<TR>
		<TD><B><? echo getlang("���ʼ�ҹ::l::Password"); ?></B></TD>
		<TD>: <input type = "password" name = "passwordadminx" autocomplete=off></TD>
	</TR>

<TR>
	<TD></TD>
	<TD><input  type = submit  style='color:darkred' value = "<? echo getlang("�������к�::l::Login"); ?>" name = "submit" class=frmbtn>
<input type = reset style='color:darkred'  value = "<? echo getlang("ź������::l::Reset"); ?>" name = "submit2" class=frmbtn></TD>
</TR>
</TABLE>
	
	</TD>
</TR>

</FORM>
</TABLE>


							<CENTER><BR>
							<A HREF="/<?echo $dcr;?>/library/"><? echo getlang("�к����˹�ҷ����ͧ��ش::l::Librarian system"); ?></A> : 
							<A HREF="/<?echo $dcr;?>/">Home Page</A><BR>
<BR>
</CENTER><?

	foot();
}
?>