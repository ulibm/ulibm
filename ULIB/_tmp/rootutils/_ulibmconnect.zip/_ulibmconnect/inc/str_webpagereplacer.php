<?
function str_webpagereplacer($str) {

	$s=tmq("select * from webpage_textreplacer where active='yes' order by ordr");
	while ($r=tmq_fetch_array($s)) {
		//echo "[$r[str1],$r[str2]]";
		$str=str_replace(stripslashes($r[str1]),stripslashes($r[str2]),$str);
	}
	return $str;
}
?>