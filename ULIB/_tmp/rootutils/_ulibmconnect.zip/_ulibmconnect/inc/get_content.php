<?
function get_content($dbnamex, $table , $insertmode="") {
		$sql = "SHOW columns FROM $table";
		$result = tmq($sql);
		$my_col=Array();
		while ($r=tmq_fetch_array($result)) {
			$my_col[]=$r[0];
		}

        global $host;
        global $user;
        global $passwd;
/*
		$connx=Mysql_connect($host, $user, $passwd,true);
        if (!$connx) {
            die(getlang("�Դ��͡Ѻ MYSQL Server �����::l::Cannot connect to MYSQL Server"));
		}
		if (!mysql_select_db($dbnamex, $connx)) {
			die(getlang("�������ö���͡��ҹ�ҹ������ [$dbnamex]::l::Cannot use specified database [$dbnamex]"));
		}*/
        global $conn;
        $content="";
        $result=mysql_query("SELECT * FROM $table");
        while ($row=mysql_fetch_row($result))
            {
            $insert = "INSERT $insertmode INTO $table set ";
            for ($j=0; $j < mysql_num_fields($result); $j++)
                {
				$insert.="$my_col[$j]=";
                if (!isset($row[$j]))
                    $insert.="NULL,";
                else if ($row[$j] != "")
                    $insert.="'" . addslashes($row[$j]) . "',";
                else
                    $insert.="'',";
                }
            //$insert=str_replace(",$", "", $insert);
			$insert=rtrim($insert,",");
            $insert.=";#%%\n";
            $content.=$insert;
            }
        return $content;
        }

?>