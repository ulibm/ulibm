<?


    $Sstr='<table width="550" border="1" cellspacing="0" cellpadding="3" align="center">
  <tr>
    <td bgcolor="f2f2f2"><img src="/' . $dcr . '/B.JPG" width="24" 
height="24" 
align="absmiddle"><font face="MS Sans Serif" size="2"><b>'.getlang("�к������::l::System message").'</b></font></td>
  </tr>
  <tr>
    <td>&nbsp;';
    $Estr='</td>
    </tr>
  </table>
  ';
?>