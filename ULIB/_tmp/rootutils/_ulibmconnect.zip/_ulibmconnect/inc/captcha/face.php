<?
;
include("../config.inc.php");
html_start();
?><img src="index.php?fake=captcha.png">