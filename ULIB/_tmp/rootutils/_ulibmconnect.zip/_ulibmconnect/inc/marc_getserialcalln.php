<?
function marc_getserialcalln($md,$mode="full") {
	$s=tmq("select * from media_mid where id='$md' ");
	$s=tmq_fetch_array($s);
	$res=marc_getcalln($s[pid]) . " " .serial_get_volstr($s[id],"no") ." " ;
	if ($mode=="full") {
		if (trim($s[inumber])!="�.") {
			$res.=$s[inumber];
		}
	}
	return "(".trim($res).")";
}
?>