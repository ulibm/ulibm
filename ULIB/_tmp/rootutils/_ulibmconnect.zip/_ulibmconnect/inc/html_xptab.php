<?
    function html_xptab($str) {
		//frm= defaultindex::color::text,url::text,url
		//default=yes/no
		//color=b g o pu r
		global $dcrURL;
		global $_TBWIDTH;
		$str=explode("::",$str);
		list($k,$vdefault)=each($str);
		list($k,$vcolor)=each($str);

?><TABLE  border = "0" cellspacing = "0" cellpadding =0 width="<? echo $_TBWIDTH;?>" align=center>
<TR>
<?
	$count=0;
	while (list($k,$v)=each($str)) {
		$count++;
		$i=explode(',',$v);
		//printr($i);
		if ($i[3]=="") {
			$i[3]="_self";
		}
		?>

	<TD background="<?echo $dcrURL?>neoimg/mediatab/menu<? echo $vcolor?>_bg.gif" >
	<? if ($count==$vdefault) {?>
	<img src='<?echo $dcrURL?>neoimg/mediatab/menu<? echo $vcolor?>_hover_left.gif'>
	<?} else {	?>
	<img src='<?echo $dcrURL?>neoimg/mediatab/menu<? echo $vcolor?>_bg.gif'>
	<?}?>
	</TD>
	<TD 
	<? if ($count==$vdefault) {?>
	background='<?echo $dcrURL?>neoimg/mediatab/menu<? echo $vcolor?>_hover_right.gif' 
	<?} else {?>
	background="<?echo $dcrURL?>neoimg/mediatab/menu<? echo $vcolor?>_bg.gif"
	<?}?>
	style="background-position: top right; padding-right: 10px;padding-left: 4px;">
<nobr>
<a  href="<?  echo $i[1]; ?>" target="<? echo $i[3]?>" 
	<? if ($count==$vdefault) {?>
	style="color:white;font-size:14px;font-weight:bold"
	<?} else {?>
	style="color:black;font-size:14px;font-weight:bold"
	<?}?>>
<? echo getlang($i[0]); ?></a>&nbsp;&nbsp; </nobr></TD>	
<?
	}
?>
<TD background="<?echo $dcrURL?>neoimg/mediatab/menu<? echo $vcolor?>_bg.gif" width=100%>&nbsp;</TD>
</TR>
</TABLE>
<?
        }
?>