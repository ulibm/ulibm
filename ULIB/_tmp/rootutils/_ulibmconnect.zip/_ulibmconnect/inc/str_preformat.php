<?
function str_preformat($str) {
	global $newline;
	$str=str_replace(' ','&nbsp;',$str);
	$str=str_replace($newline,'<BR>',$str);
	return $str;
}
?>