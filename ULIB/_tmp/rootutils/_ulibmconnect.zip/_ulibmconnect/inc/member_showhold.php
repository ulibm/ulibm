<?
function member_showhold($useradminid2) {
	global $thaimonstrbrief;
	global $isatcirculation;
	global $Level;
	global $dcrURL;
	global $dcrs;
	global $_TBWIDTH;
	global $loginadmin;
		//���������¡��
	 $s=tmq("select * from member where UserAdminID='$useradminid2' ");
  	 if (tmq_num_rows($s)!=1) {
  		die("member where UserAdminID='$useradminid2'");
  		//error will display in display iframe
  	 }
		 
	 $s=tmq_fetch_array($s);
	 	$tmpmbtype="SELECT *  FROM member_type where type ='$s[type]' "; 
		$tmpmbtype=tmq($tmpmbtype);
		if (tmq_num_rows($tmpmbtype) == 0) {
			html_dialog("","��辺 ��������Ҫԡ $mbtype ::l:: member type not found $mbtype");
			die;
		}
		$tmpmbtype=tmq_fetch_array($tmpmbtype);
		$limithold=$tmpmbtype[limithold];
		$mbtype=$s[type];
		$member_room=floor($s[room]);
		$member_major=floor($s[major]);

		$decis=member_isoverduing($useradminid2);


                                $sql="select * from checkout where hold='$useradminid2' and allow='yes' and returned='no' order by id asc";
                                $result=tmq($sql);
                                $Num=tmq_num_rows($result);
								?><BR><?
                                    pagesection("��¡�����::l::Holding item","narrow");
                                $count=1;
                                $allfine=0;
                                echo "<table border=1 cellspacing=0 width='$_TBWIDTH' align='center'  class=table_border>";
                                echo "<tr bgcolor=f2f2f2>
<td width=10 align=center  class=table_head><nobr>&nbsp;".getlang("�ӴѺ���::l::No.")."&nbsp;</td>
<td align=center  class=table_head><nobr>&nbsp;".getlang("��������´::l::Detail")."&nbsp;</td>
<td align=center  class=table_head width=10%><nobr>&nbsp;".getlang("������::l::Type")."&nbsp;</td>
<td align=center  class=table_head>&nbsp;".getlang("�ѹ���::l::Hold date")."&nbsp;</td>
<td align=center  class=table_head>".getlang("�ѹ��::l::Return date")."</td>
<td align=center  class=table_head>".getlang("��һ�Ѻ::l::Fine")."</td>
</tr>";
	while ($row2=tmq_fetch_array($result)) {
		$idhandler = $row2[id];
		$mediaId=$row2[mediaId];
		$mediapid=$row2[pid];
		$RESOURCE_TYPE=$row2[RESOURCE_TYPE];
		$sdat=$row2[sdat];
		$smon=$row2[smon];
		$syea=$row2[syea];
		$edat=$row2[edat];
		$emon=$row2[emon];
		$eyea=$row2[eyea];
		//echo "[[[end=$eyea start=$syea]]]";   
		$xfine=$row2[fine];

		echo "<tr>";
		echo "<td class=table_td align=center>$count</td>";
		echo "<td align=center  class=table_td>
<a href='$dcrURL"."dublin.php?ID=$mediapid&item=$mediaId' target=_blank><!-- $mediaId -->".substr(marc_gettitle($mediapid),0,40)."...</td>";
		echo "<td align=center  class=table_td><font color='$colsr' ><nobr class=smaller2>";
					
echo "<img border=0 width=18 height=18 src='";
	if (file_exists("$dcrs/_tmp/mediatype/$RESOURCE_TYPE.png")==true) {
		echo "$dcrURL/_tmp/mediatype/$RESOURCE_TYPE.png";
	} else {
		echo "$dcrURL/_tmp/mediatype.png";
	}
	echo "' alt='".getlang($rectype[name])."' align=absmiddle> ";
		echo get_media_type($RESOURCE_TYPE);
		echo "</nobr></td>";
		echo "<td align=center class=table_td><font color='$colsr' >$sdat " . $thaimonstrbrief[$smon] . " $syea</td>";

		echo "<td align=center class=table_td><font color='$colsr' >";
		$tmpdecis=getduedecis($mediaId, date("j"), date("n"), date("Y"));//xxxxx
//echo date("Y");
$daydiff=ddx(date("j"),date("n"),date("Y"),$edat,$emon,$eyea-543);
$daydiff=round($daydiff);

		if ($tmpdecis < 0) {
			$tmpdeci2=-($tmpdecis);
		} else {
			$tmpdeci2=$tmpdecis;
		 }
					$chkrenew="SELECT *  FROM checkout_rule where media_type ='$RESOURCE_TYPE' and member_type='$mbtype'";
					$chkrenew=tmq($chkrenew,false);
					$chkrenewr=tmq_fetch_array($chkrenew);
		echo "$edat " . $thaimonstrbrief[$emon] . " $eyea ";
		$decis=member_isoverduing($useradminid2);
		if ($decis=="PASS" && $row2[renewcount]<$chkrenewr[renew] &&$daydiff<=floor(getval("config","daydiff-torenew")) && loginchk_lib("check")==false && $row2[request]=='') {
			echo "<BR><A HREF=\"renew.php?mid=$mediaId\"><B>".getlang("������::l::Renew")."</B> ($row2[renewcount]/$chkrenewr[renew])</A>";
		}
		echo "</td>";
		if ($tmpdecis >= 0) {
			echo "<td align=center class=table_td>";
			$tmpfine=($tmpdecis * $xfine);
			$allfine+=$tmpfine;
			if (floor($tmpfine)>0) {
				echo "<font  color=red><B>";
			}
			echo number_format($tmpfine);
			echo "</b></font></td>";
		} else {
			echo "<td align=center class=table_td>";
			echo "-";
			echo "</td>";
		}
		echo "</tr>";
		if ($isatcirculation=="yes") {
			echo "<TR>
			<TD colspan=1></TD>
			<TD colspan=4 align=right class=smaller>".
			getlang("������::l::Barcode")." $row2[mediaId]";
			//renew btn
					if ($decis=="PASS" && $row2[renewcount]<$chkrenewr[renew] && $daydiff<=floor(getval("config","daydiff-torenew")) && loginchk_lib("check")==true && $row2[request]=='') {
						$Fdat=intval(date("d"));
						$Fmon=intval(date("m"));
						$Fyea=intval(date("Y")+543);
						echo "	<B><A HREF='working.viewmember.php?"."cirmode=checkout&memberbarcode=$useradminid2&mediabarcode=$row2[mediaId]&Fdat=$Fdat&Fmon=$Fmon&Fyea=$Fyea&confirm_forautorenew=yes"."' notarget=_SELF  class='smaller a_btn'>". getlang("������::l::Renew")."</A></B><font class=smaller2>($row2[renewcount]/$chkrenewr[renew])</font>";
					}



		$mbtype=$s[type];
			echo "	<B><A HREF=\"$dcrURL/circulation/main.checkin.php?mediabarcode=$row2[mediaId]\" target=main  class='smaller a_btn'>". getlang("��ԡ���ͤ׹::l::Click to Checkin")."</A></B>";
			echo "	<B><A HREF=\"$dcrURL/circulation/working.lost2.php?damagebarcode=$row2[mediaId]\" target=working class='smaller a_btn'>". getlang("���/���ش::l::Lost/damage")."</A></B>";
			
			echo "</TD>
			</TR>";
		}
		$count++;
	}
	if ($count == 1) {
		echo "<tr><td align=center colspan=20>".getlang("�������¡�����::l::No holding item.")."</td></tr>";
	 } else {


		if ($decis!="PASS" && loginchk_lib("return")) {
			echo "<TR>
			<TD colspan=6 align=right>".
			getlang("��˹ѧ��ͤ�ҧ�� �ҡ��ͧ��þ����㺷ǧ���::l::Some item(s) overdue to print notification")." 
			<A HREF=\"$dcrURL/library.download/_notification.php?id=$useradminid2\" target=_blank>".
			getlang("��سҤ�ԡ�����::l::click here")."</A>
			</TD>
			</TR>";
		}
	}
	
	

		
	//��������仡����¡������
	$sql3="SELECT *  FROM checkout where hold ='$useradminid2' and allow='yes' and returned='no' ";
	$result3=tmq($sql3);
	$row3=tmq_fetch_array($result3);
	$holded=tmq_num_rows($result3);
	if ($limithold > $holded) {
		$holdmsg= getlang("������ա " . ($limithold - $holded) . " ��¡��::l::Can checkout  " . ($limithold - $holded) . " item more");
	} else {
		$holdmsg=getlang("�������ö�����ʴ����ʹ��������::l::Cannot checkout more items");
	}
	echo "
<tr><td colspan=6 align=right class=table_td><b>$holdmsg</b></td></tr>
";
	
	
                                echo "</table>";

}
?>