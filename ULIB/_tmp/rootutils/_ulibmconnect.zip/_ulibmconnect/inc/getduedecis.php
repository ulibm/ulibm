<?
function getduedecis($tmp, $Fdat, $Fmon, $Fyea) {
		//echo "getduedecis($tmp, $Fdat, $Fmon, $Fyea)";
		//echo $Fyea;
		$Fyea = $Fyea; //��Ѻ�� �.�.

		$sqlchk="select * from checkout where mediaId='$tmp'";
        //echo "$sqlchk";
        $result1chk=tmq($sqlchk);
		if (tmq_num_rows($result1chk)==0) {
			die("getduedecis($tmp, $Fdat, $Fmon, $Fyea) cannot find from checkout where mediaId='$tmp' ");
		}
        echo mysql_error();
        $row1chk=tmq_fetch_array($result1chk);
        $edat=$row1chk[edat];
        $emon=$row1chk[emon];
        $eyea=$row1chk[eyea]-543;
        $xfine=$row1chk[fine];
        $mdtitle=$row1chk[mediaName];
        $requestid=$row1chk[request];
        $gbisrq=$row1chk[request];
        $smemberid=$row1chk[hold];
        //echo "��˹��� $edat $emon $eyea";
        /////////////////////////////////
        ///////////////// �֧�������ѹ��ش
        $sql4cf="SELECT * FROM closeservice ";
        if ($result4cf=tmq($sql4cf)) {
            //echo "�֧�����Ũҡ���ҧ closeservice ��";
       } else {
            echo "�������ö�Դ���ҧ closeservice " . mysql_error();
						die;
       }
        $closeserv="";
		while ($row4cf=tmq_fetch_array($result4cf)) {
			$cdat = $row4cf[dat];
			$cmon=$row4cf[mon];
			if ($row4cf[yea]!=-1) {
				$cyea=$row4cf[yea]-543;
			} else {
				$cyea=date('Y');
			}
			$closeserv="$closeserv $cdat.$cmon.$cyea"; //���ҧ text array ����Ѻ�ѹ��ش
			if ($row4cf[yea]==-1) {
				$cyea=date('Y')+1; //new year eve!
				$closeserv="$closeserv $cdat.$cmon.$cyea";
			}
		}

        //echo "[$closeserv]";

        $tmpdecis=ddxl($edat, $emon, $eyea, $Fdat, $Fmon, $Fyea); 
        //$tmpdecis=ddxl( $Fdat, $Fmon, $Fyea, $edat, $emon, $eyea); 
		// �� text array ������ѹ����Թ��˹���
		//echo $tmpdecis; 
        $closeserv=trim($closeserv);
        $tmpdecis=trim($tmpdecis);
        //echo "<hr>[tmpdecis>>$tmpdecis<<";
        $closes=explode(" ", $closeserv);
        //echo "<hr>[closeserv>>$closeserv<<";
        foreach ($closes as $closesi) {
            $tmpdecis=str_replace("$closesi", "", $tmpdecis); 
			//ź�ѹ���ç�Ѻ�ѹ��ش�͡ �¡��᷹�����¤����ҧ
		}

	//echo "<hr>[tmpdecisReplaced>>$tmpdecis<<";
        //echo $tmpdecis;
        $tmpdecis=rem2space($tmpdecis);
        $tmpdecis2=explode(" ", $tmpdecis);
        $tmpdecis=0; //count($tmpdecis);
        foreach ($tmpdecis2 as $tmpdecisc) {
            if ($tmpdecisc != "") {
                //echo "<U>$tmpdecisc</U> ";
                $tmpdecis++;
                }
            }
        return $tmpdecis;
}
?>