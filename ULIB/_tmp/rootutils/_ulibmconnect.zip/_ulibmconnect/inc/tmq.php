<?
function tmq($q,$isshow = "") {
	///$isshow=true;
	//ConnDB();
	//global $IPADDR; if ($IPADDR=="10.112.223.166") {$isshow=true;}
	global $_SESSION;
	global $_POST;
	global $_GET;
	global $dbname;
	global $_autosave_dbsql;
	global $conn;
	$tmp=mysql_query( $q,$conn);
	$tmpe= mysql_error();
	if ($tmpe!="") {
		echo "<FONT COLOR=red>".$tmpe."</FONT><HR><PRE>$q</PRE>";
	}
	if ($isshow!="") {
		echo "<BLOCKQUOTE><PRE>$q</PRE></BLOCKQUOTE>";
	}

	////////////////////////////startlog
	if ($_autosave_dbsql=="yes") {
		$strsavestag = strtolower(substr(trim($q), 0,5));
		if ($strsavestag == "delet" || $strsavestag=="updat" || $strsavestag=="inser") {
			filelogs("tmq","$q","autosave_dbsql-date-".date("d"));
			filelogs("tmq","SESSION=".print_r($_SESSION,true)."<HR>
			POST=".print_r($_POST,true)."<HR>
			GET=".print_r($_GET,true),"autosave_dbsql-date-".date("d"));
		} 
	}
	////////////////////////////endlog
	return $tmp;
}

?>