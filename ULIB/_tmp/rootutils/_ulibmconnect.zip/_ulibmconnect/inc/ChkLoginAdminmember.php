<?
    /*�ѧ���蹵�Ǩ�ͺ Login ��� Password */
    function ChkLoginAdminmember($useradminid, $passwordadmin) {
        $userSQL="Select * From member Where UserAdminID='$useradminid'  AND statusactive ='normal' ";
        //echo $userSQL;
        $result=tmq($userSQL);
        $num=tmq_num_rows($result);
		//echo "[$num]";
		if ($num!=1) {
			if (barcodeval_get("webpage-o-canmemberloginbyemail")=="yes" && umail_chk($useradminid)) {
				$userSQL="Select * From member Where email='$useradminid'  AND statusactive ='normal' ";
				$result=tmq($userSQL);
				$num=tmq_num_rows($result);
			} else {
				return false;
			}
		}
        $rs=tmq_fetch_array($result);
		//printr($rs);
	   if ($rs[Password]!=$passwordadmin) {
		return false;
	   }
		
        if ($num!=1)
            return false;
        else
            return $rs[UserAdminID];
        }
?>