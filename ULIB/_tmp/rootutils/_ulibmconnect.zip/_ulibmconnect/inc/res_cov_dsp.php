<?
function res_cov_dsp($mid,$tags="no",$width=100,$reflect="no",$addition_html="") {
	global $dcrURL;
	global $dcrs;
	$res="";
	if ($tags=="no") {
		$tags=tmq("select * from media where id='$mid' ");
		$tags=tmq_fetch_array($tags);
	}

	$cov=tmq("select * from media_ftitems where mid='$mid' and fttype='cover' order by text limit 1");
	if (tmq_num_rows($cov)!=0) {
	  $covr=mysql_fetch_array($cov);
		if($covr[uploadtype]=="url") {
			$addurltail="";
			$covurl=$covr[filename];
		} else {
			$addurltail=".thumb.jpg";
			$covurl="$dcrURL/_fulltext/$covr[fttype]/$covr[mid]/$covr[filename]";
			$covdcrs=$dcrs."_fulltext/$covr[fttype]/$covr[mid]/$covr[filename]";
			$covdcrst=$covdcrs.".thumb.jpg";
			if (!file_exists($covdcrst)) {
				@copy($covdcrs,$covdcrst);
				$ext=explode('.',$covdcrs);
				//printr($ext);
				$ext=$ext[count($ext)-1];
				//echo $ext;
				fso_image_fixsize($covdcrst,"$ext",120);
			}
		}
		$res .= "<img  $addition_html src='$covurl$addurltail' border=1 style='border-color:black; float: left;style='border: solid 1px black; border-left-width:2; border-bottom-width:2'' width=$width hspace=0 vspace=0";
		if ($reflect=="yes") { 
			$res.=" class='reflect' ";
		}
		$res.=" $addition_html>";
	} else {
		$tags=tmq("select * from media where ID='$mid' ");
		$tags=tmq_fetch_array($tags);
		$tmpreflect="";
		if ($reflect=="yes") { 
			$tmpreflect=" class='reflect' ";
		}
		$covinfo=get_coverbyinfo($tags,"$addition_html style='float: left;' width=$width hspace=0 border=0 vspace=0 $tmpreflect $addition_html");
		if ($covinfo[ispass]=="yes") {
			$res .=  $covinfo[html];
		}
	}
	//echo "[$res]";
	if ($res=="") {
		$res="<img  $addition_html src='$dcrURL/neoimg/nocover.png' border=1 style='border-color:black; float: left; style='border: solid 1px black; border-left-width:2; border-bottom-width:2;'' width=$width hspace=0 vspace=0";
		if ($reflect=="yes") { 
			$res.=" class='reflect' ";
		}
		$res.=" $addition_html>";
	}
	return $res;
}
?>