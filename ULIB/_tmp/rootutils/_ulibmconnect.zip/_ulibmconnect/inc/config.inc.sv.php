<?
$_ISULIBMASTER="ulibm";
$_detatchbibfrombibacc="ulibm";
?>