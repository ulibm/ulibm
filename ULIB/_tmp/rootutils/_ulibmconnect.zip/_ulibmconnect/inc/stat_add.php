<?
function stat_add($tbl,$id) {
	$tbl=addslashes($tbl);
	$id=addslashes($id);

 $tbl="stat_$tbl";
 $dat=date("j");
 $mon=date("n");
 $yea=date("Y");
 
 $c=tmq("select id from $tbl where dat='$dat' and mon='$mon' and yea='$yea' and head='$id'  ",false);
 $now=time();
 if (tmq_num_rows($c)==0) {
 		tmq("insert into $tbl set 
		dat='$dat' ,
		 mon='$mon' ,
		  yea='$yea' ,
			 head='$id' ,
			  cc=1 ,
				 lastdt='$now' 
		");
 } else {
   $c=tmq_fetch_array($c);
  	tmq("update $tbl set 
  			  cc=cc+1 ,
  				 lastdt='$now' 
					 where id='$c[id]'
  		",false);
 }
}
?>