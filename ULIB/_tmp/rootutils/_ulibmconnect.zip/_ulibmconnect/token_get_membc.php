<?php 
	//session_start(); 
	include("inc/config.inc.php");

	if( isset( $_GET["REFCODE"] ) ){
		sessionval_set("REFCODE",$_GET["REFCODE"]);
	}
	if( isset( $_GET["REFURL"] ) ){
		sessionval_set("REFURL",$_GET["REFURL"]);
	}

	$s=tmq("select * from ulibmconnect_access where randid='$token' and refcode='".sessionval_get("REFCODE")."'  ");
	$s=tmq_fetch_array($s);
	echo $s[membc];
?>