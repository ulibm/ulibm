<?php
	//session_start(); 
	include("inc/config.inc.php");




	// config and whatnot
    $config = dirname(__FILE__) . '/hybridauth/config.php';
    require_once( "hybridauth/Hybrid/Auth.php" );

if (sessionval_get("REFCODE")=="" || sessionval_get("REFURL")=="") {
	?> ���������§�Դ��Ҵ ��سҡ� <a href="javascript:history.go(-1);">Back</a> �˹�ҡ�͹˹��<?
	die;
}

	$user_data = NULL;

	// try to get the user profile from an authenticated provider
	try{
		$hybridauth = new Hybrid_Auth( $config );

		// selected provider name 
		$provider = @ trim( strip_tags( $_GET["provider"] ) );

		// check if the user is currently connected to the selected provider
		if( !  $hybridauth->isConnectedWith( $provider ) ){ 
			// redirect him back to login page
			header( "Location: login.php?error=Your are not connected to $provider or your session has expired" );
		}

		// call back the requested provider adapter instance (no need to use authenticate() as we already did on login page)
		$adapter = $hybridauth->getAdapter( $provider );

		// grab the user profile
		$user_data = $adapter->getUserProfile();

		echo $adapter->id;
		echo "/";
		echo $user_data->identifier; 
		$s=tmq("select * from ulibmconnect where provider='".$adapter->id."' and providerid='".$user_data->identifier."' and refcode='".sessionval_get("REFCODE")."'",false);
		if (tmq_num_rows($s)!=1) {
			?>
<meta http-equiv = "Content-Type" content = "text/html; charset=TIS-620">
<meta http-equiv = "Content-Type" content = "text/html; charset=windows-874">
<br><b><?		
			echo $user_data->displayName;	
			echo "</b><br>";
			echo getlang("������͹��Ҥس�ѧ�����������§�ѭ�� ".$adapter->id." ���Ѻ���䫵��� <br><a href='".sessionval_get("REFURL")."/member/'>��سҤ�ԡ�����</a> ���͡�Ѻ���͡�Թ������͡�Թ���ʼ�ҹ������� �ҡ��鹨֧��ԡ ������§�����š����͡�Թ  �����§�ѭ�բͧ ".$adapter->id." ��Ҵ��¡ѹ" );
			die;
		} else { // found user
			tmq("update ulibmconnect set 
			memname='".addslashes($user_data->displayName)."',
			memurl='".addslashes($user_data->profileURL)."'
			where provider='".$adapter->id."' and providerid='".$user_data->identifier."' and refcode='".sessionval_get("REFCODE")."'
			");
			$s=tmq_fetch_array($s);
			tmq("delete from ulibmconnect_access where refcode='".sessionval_get("REFCODE")."'  and membc='$s[membc]' ",false);
			$randid=randid();
			tmq("insert into ulibmconnect_access set
			randid='$randid',
			refcode='".sessionval_get("REFCODE")."'  ,
			membc='$s[membc]' ");
			redir(sessionval_get("REFURL")."member/ulibmconnect_access.php?token=$randid");
			die;
		}
    } 
	catch( Exception $e ){  
		// In case we have errors 6 or 7, then we have to use Hybrid_Provider_Adapter::logout() to 
		// let hybridauth forget all about the user so we can try to authenticate again.

		// Display the recived error, 
		// to know more please refer to Exceptions handling section on the userguide
		switch( $e->getCode() ){ 
			case 0 : echo "Unspecified error."; break;
			case 1 : echo "Hybriauth configuration error."; break;
			case 2 : echo "Provider not properly configured."; break;
			case 3 : echo "Unknown or disabled provider."; break;
			case 4 : echo "Missing provider application credentials."; break;
			case 5 : echo "Authentication failed. " 
					  . "The user has canceled the authentication or the provider refused the connection."; 
			case 6 : echo "User profile request failed. Most likely the user is not connected "
					  . "to the provider and he should to authenticate again."; 
				   $adapter->logout(); 
				   break;
			case 7 : echo "User not connected to the provider."; 
				   $adapter->logout(); 
				   break;
		} 

		echo "<br /><br /><b>Original error message:</b> " . $e->getMessage();

		echo "<hr /><h3>Trace</h3> <pre>" . $e->getTraceAsString() . "</pre>";  
	}
?>