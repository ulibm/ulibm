<?php 
	//session_start(); 
	include("inc/config.inc.php");

	// change the following paths if necessary 
	$config = dirname(__FILE__) . '/hybridauth/config.php';
	//echo $config;
	//print_r($_GET);
	if( isset( $_GET["REFCODE"] ) ){
		sessionval_set("REFCODE",$_GET["REFCODE"]);
	}
	if( isset( $_GET["REFURL"] ) ){
		sessionval_set("REFURL",$_GET["REFURL"]);
	}
	if( isset( $_GET["membc"] ) ){
		sessionval_set("membc",$_GET["membc"]);
	}

	require_once( "hybridauth/Hybrid/Auth.php" );

	// check for erros and whatnot
	$error = "";
	
	if( isset( $_GET["error"] ) ){
		$error = '<b style="color:red">' . trim( strip_tags(  $_GET["error"] ) ) . '</b><br /><br />';
	}

	// if user select a provider to login with
		// then inlcude hybridauth config and main class
		// then try to authenticate te current user
		// finally redirect him to his profile page
	if( isset( $_GET["provider"] ) && $_GET["provider"] ):
		try{
			// create an instance for Hybridauth with the configuration file path as parameter
			$hybridauth = new Hybrid_Auth( $config );
 
			// set selected provider name 
			$provider = @ trim( strip_tags( $_GET["provider"] ) );

			// try to authenticate the selected $provider
			$adapter = $hybridauth->authenticate( $provider );
			$user_data = $adapter->getUserProfile();
			// if okey, we will redirect to user profile page 
			//$hybridauth->redirect( "manage.php?add=yes&provider=$provider" );
			if ($add=="yes") {
				tmq("delete from ulibmconnect where provider='".$adapter->id."' and providerid='".$user_data->identifier."' and refcode='".sessionval_get("REFCODE")."'");
				tmq("insert into ulibmconnect set
				provider='".$adapter->id."' ,
				memurl='".addslashes($user_data->profileURL)."' ,
				memname='".addslashes($user_data->displayName)."' ,
				membc='".sessionval_get("membc")."' ,
				providerid='".$user_data->identifier."' ,
				refcode='".sessionval_get("REFCODE")."'");
			}
		}
		catch( Exception $e ){
			// In case we have errors 6 or 7, then we have to use Hybrid_Provider_Adapter::logout() to 
			// let hybridauth forget all about the user so we can try to authenticate again.

			// Display the recived error, 
			// to know more please refer to Exceptions handling section on the userguide
			switch( $e->getCode() ){ 
				case 0 : $error = "Unspecified error."; break;
				case 1 : $error = "Hybriauth configuration error."; break;
				case 2 : $error = "Provider not properly configured."; break;
				case 3 : $error = "Unknown or disabled provider."; break;
				case 4 : $error = "Missing provider application credentials."; break;
				case 5 : $error = "Authentication failed. The user has canceled the authentication or the provider refused the connection."; break;
				case 6 : $error = "User profile request failed. Most likely the user is not connected to the provider and he should to authenticate again."; 
					     $adapter->logout(); 
					     break;
				case 7 : $error = "User not connected to the provider."; 
					     $adapter->logout(); 
					     break;
			} 

			// well, basically your should not display this to the end user, just give him a hint and move on..
			$error .= "<br /><br /><b>Original error message:</b> " . $e->getMessage(); 
			$error .= "<hr /><pre>Trace:<br />" . $e->getTraceAsString() . "</pre>";
		}
    endif;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en">
<head>
<title>ULibM Connect</title>
<link rel="stylesheet" type="text/css" href="zocial.css" />
<link rel="stylesheet" href="public/css.css" type="text/css">

<meta http-equiv = "Content-Type" content = "text/html; charset=TIS-620">
<meta http-equiv = "Content-Type" content = "text/html; charset=windows-874">

</head>
<body>
<center>
<!-- <h1>ULibM Connect</h1>  -->

<?php

if (sessionval_get("REFCODE")=="" || sessionval_get("REFURL")==""|| sessionval_get("membc")=="") {
	?> ���������§�Դ��Ҵ ��سҡ� <a href="javascript:history.go(-1);">Back</a> �˹�ҡ�͹˹��<?
	die;
}
	// if we got an error then we display it here
	if( $error ){
		echo '<p><h3 style="color:red">Error!</h3>' . $error . '</p>';
		echo "<pre>Session:<br />" . print_r( $_SESSION, true ) . "</pre><hr />";
	}
?>

<table width="100%" border="0" cellpadding="2" cellspacing="0">
  <tr> 
    <td align="left" valign="top"> 

        <b><? echo getlang("�������������§��͡�Թ�ͧ::l::Connect with one of these providers");?></b><br>
		<?
		$hybridauth = new Hybrid_Auth( $config );
		//print_r($hybridauth);
			foreach( Hybrid_Auth::$config["providers"] as $idpid => $params ) {
				if ($params[enabled]==true) {
					//echo " $idpid => $params "; print_r($params); echo "<hr>";
					?> <a href="?add=yes&provider=<? echo $idpid;?>" class="zocial <? echo strtolower($idpid);?>" ><? echo $idpid;?></a> <?
				}
		}
		?><!-- 
			&nbsp;&nbsp;<a href="?provider=Google" class="zocial google">Sign-in with Google</a><br /> 
			&nbsp;&nbsp;<a href="?provider=Yahoo">Sign-in with Yahoo</a><br /> 
			&nbsp;&nbsp;<a href="?provider=Facebook">Sign-in with Facebook</a><br />
			&nbsp;&nbsp;<a href="?provider=Twitter">Sign-in with Twitter</a><br />
			&nbsp;&nbsp;<a href="?provider=MySpace">Sign-in with MySpace</a><br />  
			&nbsp;&nbsp;<a href="?provider=Live">Sign-in with Windows Live</a><br />  
			&nbsp;&nbsp;<a href="?provider=LinkedIn">Sign-in with LinkedIn</a><br /> 
			&nbsp;&nbsp;<a href="?provider=Foursquare">Sign-in with Foursquare</a><br /> 
			&nbsp;&nbsp;<a href="?provider=AOL">Sign-in with AOL</a><br />   -->
      </fieldset> 
	</td> 
<?php 
	// try to get already authenticated provider list
	try{
		$hybridauth = new Hybrid_Auth( $config );

		$connected_adapters_list = $hybridauth->getConnectedProviders(); 

		if( count( $connected_adapters_list ) ){
?> 
    <td align="left" valign="top">  

			<b><?echo getlang("����͡�Թ������ǡѺ::l::Providers you are logged with");?></b><br>
			<?php
				foreach( $connected_adapters_list as $adapter_id ){
					echo '  <a href="manage.php?add=yes&provider=' . $adapter_id . '"><b>' . $adapter_id . '</b> </a> '; 
				}
			?> 
	</td>		
<?php
		}
	}
	catch( Exception $e ){
		echo "Ooophs, we got an error: " . $e->getMessage();

		echo " Error code: " . $e->getCode();

		echo "<br /><br />Please try again.";

		echo "<hr /><h3>Trace</h3> <pre>" . $e->getTraceAsString() . "</pre>"; 
	}
?> 
  </tr> 
</table>
</center>
<?
if ($delete!=0) {
	tmq("delete from ulibmconnect where  refcode='".sessionval_get("REFCODE")."' and membc='".sessionval_get("membc")."' ");
}
echo "<br><br><b>��͡�Թ�����������§�������</b><br>";
?><table cellspacing=0 cellpadding=3 border=0 width=100% bgcolor=f2f2f2 >
<tr>
	<td><?
		$s=tmq("select * from ulibmconnect where  refcode='".sessionval_get("REFCODE")."'",false);
	while ($r=tmq_fetch_array($s)) {
		?> <font  class="zocial <? echo strtolower($r[provider]);?> icon" ><? echo $r[provider];?></font> User <b><? echo stripslashes($r[memname]) ;?></b>: 
		<a href="<? echo $r[memurl] ;?>" target=_blank><? echo $r[memurl] ;?></a> &nbsp; <a href="manage.php?delete=<? echo $r[id];?>" onclick="return confirm('Delete?');" style="color: darkred">ź���������§</a> <br><?
	}
?></td>
</tr>
</table><?
/*

	<br />
	<br />
	
<table width="60%" border="0" cellspacing="10">
	<tr>  
	<td>
	<hr /> 
	This example show how users can login with providers using <b>HybridAuth</b>. It also show how to grab their profile, update their status or to grab their freinds list from services like facebook, twitter, myspace.
	<br />
	<br />
	If you want even more providers please goto to HybridAuth web site and download the <a href="http://hybridauth.sourceforge.net/download.html">Additional Providers Package</a>.
	</td>
	</tr>
</table>
*/
?>
<br><center>
<font style="font-size: 12px; color: black">powered by:</font> <a href="http://hybridauth.sourceforge.net/" style="font-size: 12px; color: #2f4582">http://hybridauth.sourceforge.net/</a>, <a href="http://zocial.smcllns.com/" style="font-size: 12px; color: #2f4582">http://zocial.smcllns.com/</a>
<!-- <?
echo "<br>";
echo sessionval_get("REFCODE");
echo sessionval_get("REFURL");
?> --></center>
</html>