<?php 
$addon_name="Transfer ULib Data";
$addon_execat="";
$_REQPERM="zzulibtransdata";
// พ
?>